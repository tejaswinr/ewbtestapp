package com.citigroup.ewb;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
//
//import org.apache.avro.Schema;
//import org.apache.avro.generic.GenericData;
//import org.apache.avro.generic.GenericRecord;
//import org.apache.avro.util.Utf8;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.common.util.EventTransfer;

//import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventAvroConverter;
import com.citigroup.ewb.common.util.GenericAvroDeserializer;
import com.citigroup.ewb.common.util.GenericAvroSerializer;

/**
 * 
 * @author zh22901
 *
 */
//@DisplayName("A Test case for utility classes")
//@ExtendWith(SpringExtension.class)
//@Configuration
//@PropertySource("classpath:application.properties")
//@SpringBootTest
public class UtilTest {
	
//	@Value("${schema.registry.url:http://sd-9a28-ab9d:8081}")
//	private String schemaregistryurl;
//
//    @Test
//    @DisplayName("Test GenericAvroDeserializer")
//	public void testGenericAvroDeserializerAndSerializer() {
//    	String schemaDescription = " {    \n"
//                + " \"name\": \"TradeUser\", \n"
//                + " \"type\": \"record\",\n" + " \"fields\": [\n"
//                + "   {\"name\": \"name\", \"type\": \"string\"},\n"
//                + "   {\"name\": \"num_likes\", \"type\": \"int\"},\n"
//                + "   {\"name\": \"num_photos\", \"type\": \"int\"},\n"
//                + "   {\"name\": \"num_groups\", \"type\": \"int\"} ]\n" + "}";
//    	Schema s = Schema.parse(schemaDescription);
//
//    	GenericRecord datum = new GenericData.Record(s);
//    	datum.put("name", new Utf8("ted"));
//    	datum.put("num_likes", 1);
//    	datum.put("num_groups", 423);
//    	datum.put("num_photos", 0);
//
//    	String topic = "test";
//    	GenericAvroSerializer avroSerializer = new GenericAvroSerializer();
//    	Map configs = new HashMap();
//    	configs.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaregistryurl);
//    	avroSerializer.configure(configs, false);
//    	byte[] bytes = avroSerializer.serialize(topic, datum);
//
//    	GenericAvroDeserializer avroDeserializer = new GenericAvroDeserializer();
//    	avroDeserializer.configure(configs, false);
//    	GenericRecord newdatum = avroDeserializer.deserialize(topic, bytes);
//
//    	System.out.print("num_likes = " + newdatum.get("num_likes"));
//
//    	assert(datum.get("name").equals(newdatum.get("name")));
//    	assert(datum.get("num_likes").toString().equals(newdatum.get("num_likes").toString()));
//    	assert(datum.get("num_groups").toString().equals(newdatum.get("num_groups").toString()));
//    	assert(datum.get("num_photos").toString().equals(newdatum.get("num_photos").toString()));
//    }
//
//    @Test
//    @DisplayName("Test Event serializing and encoding")
//    public void testGeneric() {
//    	Event e = EventGenerator.getNext();
//    	String eventstr = EventTransfer.debugEvent(e, null);
//    	System.out.print(eventstr);
//    	ByteBuffer bb1 = null;
//		try {
//			bb1 = e.toByteBuffer();
//		} catch (IOException e2) {
//			// TODO Auto-generated catch block
//			e2.printStackTrace();
//		}
//	   	String eventstr1 = null;
//    	try {
//			Event e1 = Event.fromByteBuffer(bb1);
//		   	eventstr1 = EventTransfer.debugEvent(e, null);
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//       	assert(eventstr.equals(eventstr1));
//
//    	ByteBuffer bb = null;
//    	try {
//    		bb = e.toByteBuffer();
//    	} catch(Exception ex) {
//    		ex.printStackTrace();
//    	}
//
//    	byte[] bytes = new byte[bb.remaining()];
//        bb.get(bytes, 0, bytes.length);
//
//    	EventTransfer et = new EventTransfer();
//    	et.wrapEvent(bytes);
//    	Event event = null;
//    	try {
//			event = et.restoreEvent();
//		} catch (IOException e21) {
//			// TODO Auto-generated catch block
//			e21.printStackTrace();
//		}
//
//    	eventstr = EventTransfer.debugEvent(event, null);
//    	eventstr1 = EventTransfer.debugEvent(e, null);
//
//       	assert(eventstr.equals(eventstr1));
//    	System.out.print(eventstr);
//
//	}
//
//    @Test
//    @DisplayName("Test Event avro converter")
//    public void testEventAvroConverter() {
//    	Event e = EventGenerator.getNext();
//
//       	String estr = EventAvroConverter.convertToStr(e);
//       	System.out.print(estr);
//
//    	Map em = EventAvroConverter.toMap(e);
//
//    	Event e1 = EventAvroConverter.mapToEvent(em);
//
//    	String e1str = EventAvroConverter.convertToStr(e1);
//       	assert(estr.equals(e1str));
//	}

}
