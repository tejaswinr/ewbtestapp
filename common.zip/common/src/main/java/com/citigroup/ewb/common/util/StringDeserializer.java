package com.citigroup.ewb.common.util;

import java.io.Closeable;
import java.nio.charset.Charset;
import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;

public class StringDeserializer implements Closeable, AutoCloseable, Deserializer<String> {
	   private static final Charset CHARSET = Charset.forName("UTF-8");

	    @Override
	    public void configure(Map<String, ?> map, boolean b) {
	    }

	    @Override
	    public String deserialize(String topic, byte[] bytes) {
	        try {
	            // Transform the bytes to String
	            String line = new String(bytes, CHARSET);
	            // Return the Person object created from the String 'person'
	            return line;
	        } catch (Exception e) {
	            throw new IllegalArgumentException("Error reading bytes", e);
	        }
	    }

	    @Override
	    public void close() {

	    }

}
