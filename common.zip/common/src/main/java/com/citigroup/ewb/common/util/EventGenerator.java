package com.citigroup.ewb.common.util;

import com.citigroup.ewb.avro.Event;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class EventGenerator {
    static long numEvents = 10000;
    static long currid = 1;
    static AtomicLong transactionIdGenerator = new AtomicLong(0L);


    static String[] COMMENTS = {"Comments on the trade transcation 1","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation","Comments on the trade transcation"};
    static String[] EXCEPTION_SOURCE = {"MOM","MOTO","TC","MOM","MOTO","TC","MOM","MOTO","TC","MOM"};
    static String[] STATUS = {"Open","Work in Progress","At Risk","Resolved","Open","Work in Progress","At Risk","Resolved","Open","Work in Progress"};
    static String[] ASSET_CLASS = {"FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB","FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB"};
    static String[] ALLOCATION_ID = {"OA_OMG1910_A7","OA_OMG1910_A1","OA_OMG1910_A2","OA_OMG1910_A3","OA_OMG1910_A4","OA_OMG1910_A5","OA_OMG1910_A6","OA_OMG1910_A8","OA_OMG1910_A9","OA_OMG1910_A0"};
    static String[] CREATED_BY = {"sy39504","sy39504","sy39504","sy39504","sy39504","tr17063","tr17063","tr17063","tr17063","tr17063"};
    static String[] FIRM_CODE = {"OMGI","KAMES","SLI","OMGI","KAMES","SLI","OMGI","KAMES","SLI","SLI"};
    static String[] PORTFOLIO_CODE = {"CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG"};
    static String[] ASSET_TYPE_CODE = {"FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB","FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB"};
    static String[] ERROR_DESCRIPTION = {"Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx"};
    static String[] ERROR_CATEGORY = {"TRADE CAPTURE","CONFIRMATION","SETTLEMENT","ACCOUNTING","DATA DELIVERY","TRADE CAPTURE","CONFIRMATION","SETTLEMENT","ACCOUNTING","DATA DELIVERY"};
    static String[] FILE_TYPE = {"OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER"};
    static String[] BLOCK_EXTERNAL_REFERENCE_ID = {"OA_BT_OMG1910_B1","OA_BT_OMG1910_B2","OA_BT_OMG1910_B3","OA_BT_OMG1910_B4","OA_BT_OMG1910_B5","OA_BT_OMG1910_B6","OA_BT_OM7",null,null,null};

    public static Event getNext() {
    	Event tradeFile = new Event();
        Random r = new Random();
        int maxSize = 50;
        long timeStamp = new Date().getTime();
        String empty = "";
        long TRANSACTION_ID  = transactionIdGenerator.incrementAndGet();
        tradeFile.setTRANSACTIONID(TRANSACTION_ID);
        tradeFile.setQUANTITY(r.nextInt(20));
        tradeFile.setCREATEDDATE(timeStamp);
        tradeFile.setCOMMENTS(COMMENTS[r.nextInt(COMMENTS.length)]);
        tradeFile.setBATCHID(Long.valueOf(r.nextInt(maxSize)));
        tradeFile.setADDITIONALDETAILS(empty);
        tradeFile.setEXCEPTIONSOURCE(EXCEPTION_SOURCE[r.nextInt(EXCEPTION_SOURCE.length)]);
        tradeFile.setCUSTODIANACCOUNT(empty);
        tradeFile.setSTATUS(STATUS[r.nextInt(STATUS.length)]);
        tradeFile.setASSETCLASS(ASSET_CLASS[r.nextInt(ASSET_CLASS.length)]);
        tradeFile.setALLOCATIONID(ALLOCATION_ID[r.nextInt(ALLOCATION_ID.length)]);
        tradeFile.setCREATEDBY(CREATED_BY[r.nextInt(CREATED_BY.length)]);
        tradeFile.setFIRMCODE(FIRM_CODE[r.nextInt(FIRM_CODE.length)]);
        tradeFile.setREMEDIATIONSTEP(empty);
        tradeFile.setPORTFOLIOCODE(PORTFOLIO_CODE[r.nextInt(PORTFOLIO_CODE.length)]);
        tradeFile.setEXECUTINGBROKER(empty);
        tradeFile.setCUSTODIAN(empty);
        tradeFile.setFILEPATH(empty);
        tradeFile.setASSETTYPECODE(ASSET_TYPE_CODE[r.nextInt(ASSET_TYPE_CODE.length)]);
        tradeFile.setERRORDESCRIPTION(ERROR_DESCRIPTION[r.nextInt(ERROR_DESCRIPTION.length)]);
        tradeFile.setLASTUPDATEDDATE(timeStamp);
        tradeFile.setERRORCATEGORY(ERROR_CATEGORY[r.nextInt(ERROR_CATEGORY.length)]);
        tradeFile.setFILETYPE(FILE_TYPE[r.nextInt(FILE_TYPE.length)]);
        tradeFile.setBLOCKEXTERNALREFERENCEID(BLOCK_EXTERNAL_REFERENCE_ID[r.nextInt(BLOCK_EXTERNAL_REFERENCE_ID.length)]);
        tradeFile.setID(String.valueOf(TRANSACTION_ID));
        tradeFile.setEXCEPTIONCATEGORY("EQTY");
        tradeFile.setBLOCKEXTERNALREFERENCEID("citi");
        return tradeFile;

    }

}