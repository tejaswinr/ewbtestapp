package com.citigroup.ewb.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.Schema;
import org.apache.log4j.Logger;

import com.citigroup.ewb.avro.Event;

public class EventAvroConverter {

	public static Map toMap(Event e) {
		Map em = new HashMap<String, String>();
		try {
		Schema s = e.getSchema();
		List<Schema.Field> fields = s.getFields();
		for (Schema.Field field : fields) {
			if (field == null) continue;
			System.out.print("Field name = " + field.name());
			em.put(field.name(),e.get(field.name()).toString());
		}
		}catch (Exception ex) {
			ex.printStackTrace();
		}
		return em;
	}

	public static Event mapToEvent(Map<String, String> em) {

		Event e= EventGenerator.getNext();

		try {
		Schema s = e.getSchema();
		List<Schema.Field> fields = s.getFields();
		for (Schema.Field field : fields) {
			if (field == null) continue;
			System.out.print("\r\nmapToEvent : Field name = " + field.name() + ". value = " + em.get(field.name()));
			Object v = e.get(field.name());

			Object obv = getValue(v,em.get(field.name()));
			if(obv != null)
				e.put(field.name(), obv);
		} }catch (Exception ex) {
			ex.printStackTrace();
		}
		e = Event.newBuilder(e).build();
		return e;
	}

	public static Object getValue(Object v, String vstr) {
		Object rtnObject = null;
		if (v instanceof CharSequence)
			rtnObject = vstr;
		else if (v instanceof Integer)
			rtnObject = Integer.valueOf(vstr);
		else if (v instanceof Long)
			rtnObject = Long.valueOf(vstr);
		if (rtnObject == null)
			rtnObject = v;
		return rtnObject;
	}

    public static String convertToStr(Event e) {
    	StringBuffer log = new StringBuffer("");

    	log.append("Debug Event Data: " + "\r\n");
    	log.append("transactionId : " + e.getTRANSACTIONID() + "\r\n");
    	log.append("type : " + e.getFILETYPE() + "\r\n");
    	log.append("tradeId : " + e.getID() + "\r\n");
    	log.append("blockId : " + e.getBLOCKEXTERNALREFERENCEID() + "\r\n");
    	log.append("firmCode : " + e.getFIRMCODE() + "\r\n");
    	log.append("assetClass : " + e.getASSETCLASS()+ "\r\n");
    	log.append("custodian : " + e.getCUSTODIAN() + "\r\n");
    	log.append("source : " + e.getEXCEPTIONSOURCE() + "\r\n");
    	log.append("stage : " + e.getSTATUS() + "\r\n");
    	log.append("category : " + e.getEXCEPTIONCATEGORY() + "\r\n");
    	log.append("description : " + e.getERRORDESCRIPTION() + "\r\n");

    	return log.toString();
    }
}
