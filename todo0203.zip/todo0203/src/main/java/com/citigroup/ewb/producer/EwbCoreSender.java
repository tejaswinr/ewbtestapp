package com.citigroup.ewb.producer;

//import com.citigroup.ewb.avro.Event;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.stereotype.Component;


//@Component
public class EwbCoreSender {

//  private static final Logger LOGGER = LoggerFactory.getLogger(EwbCoreSender.class);
//
//  @Value("${kafka.topic.avro}")
//  private String avroTopic;
//
//  @Autowired
//  private KafkaTemplate<String, Event> kafkaTemplate;
//
//  public void send(String key, Event event) {
//    LOGGER.info("sending tradeFile='{}' ", event.toString());
//    kafkaTemplate.send(avroTopic, key,event);
//  }
}
