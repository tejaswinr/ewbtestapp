package com.citigroup.ewb.controllers;




import com.citigroup.ewb.service.CoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class EwbController {



    @Autowired
    CoreService coreService;


    @RequestMapping(value="/publish")
    public String publish() {

        Event event = EventGenerator.getNext();
        System.out.println("transId ---  " + event.getTransactionId());
        return coreService.publish(event);


    }

}
