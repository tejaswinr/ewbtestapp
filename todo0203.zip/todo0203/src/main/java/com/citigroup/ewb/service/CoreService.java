package com.citigroup.ewb.service;


//import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.producer.EwbCoreSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


//@Component
public class CoreService {

//    @Autowired
//    EwbCoreSender producer;
//
//    public String publish(Event event){
//        String key= String.valueOf(event.getTransactionId());
//        try {
//            if (event != null) {
//                producer.send(key, event);
//            }
//        }catch(Exception ex){
//            ex.printStackTrace();
//           return "unable to publish";
//        }
//        return "published with key " +key;
//    }
}


