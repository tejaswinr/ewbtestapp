package com.citigroup.ewb;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;


@SpringBootApplication
@EnableAsync
public class SpringKafkaApplication {

    public static void main(String[] args) {
        //SpringApplication.run(SpringKafkaApplication.class, args);
        SpringApplication app = new SpringApplication(SpringKafkaApplication.class);
        app.run(args);
    }
}
