package com.ewb.config.client;

public enum KafkaClientType {

	PRODUCER,
	CONSUMER
}
