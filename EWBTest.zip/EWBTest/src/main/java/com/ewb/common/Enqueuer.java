package com.ewb.common;

public interface Enqueuer<T> {

	public void enqueue(T object) throws InterruptedException;

}
