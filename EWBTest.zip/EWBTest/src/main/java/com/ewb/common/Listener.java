package com.ewb.common;

public interface Listener<T> {

	public void updateListener(T object);
}
