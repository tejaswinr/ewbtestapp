package com.ewb.kafkamessage;

import java.util.concurrent.BlockingQueue;

import com.ewb.common.AbstractDequeuer;

public class KafkaMessageEnqueuerImpl extends AbstractDequeuer<KafkaMessage> {

	public KafkaMessageEnqueuerImpl(BlockingQueue<KafkaMessage> outboundQueue, int pollTimeout) {
		super(outboundQueue, pollTimeout);
	}

	public KafkaMessageEnqueuerImpl(BlockingQueue<KafkaMessage> outboundQueue) {
		super(outboundQueue);
	}

	@Override
	public KafkaMessage dequeue() {
		// TODO Auto-generated method stub
		return null;
	}

}
