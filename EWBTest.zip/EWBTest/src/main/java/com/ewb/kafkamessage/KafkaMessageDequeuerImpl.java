package com.ewb.kafkamessage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import com.ewb.common.AbstractDequeuer;
import com.ewb.common.Listener;

public class KafkaMessageDequeuerImpl extends AbstractDequeuer<KafkaMessage> implements Runnable {

	private List<Listener<KafkaMessage>> kafkaMessageListeners;

	public KafkaMessageDequeuerImpl(BlockingQueue<KafkaMessage> outboundQueue) {
		super(outboundQueue);
	}

	public KafkaMessageDequeuerImpl(BlockingQueue<KafkaMessage> outboundQueue, int pollTimeout) {
		super(outboundQueue, pollTimeout);
	}

	private void updateKafkaMessageListeners(KafkaMessage event) {
		for (Listener<KafkaMessage> kafkaMessageListener : kafkaMessageListeners) {
			kafkaMessageListener.updateListener(event);
		}
	}

	public void registerEventListener(Listener<KafkaMessage> listener) {
		if (kafkaMessageListeners == null) {
			kafkaMessageListeners = new ArrayList<>();
		}
		kafkaMessageListeners.add(listener);
	}

	@Override
	public void run() {
		// TODO
		while (true) {
			try {
				KafkaMessage message = dequeue();
				if (message == null) {
					continue;
				}
				updateKafkaMessageListeners(message);
			} catch (InterruptedException e) {
				// LOGGER
				e.printStackTrace();
			}
		}

	}

}
