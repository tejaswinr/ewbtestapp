package com.ewb.kafkamessage;

import com.ewb.event.entity.Event;

public class KafkaMessageFactory {

	public KafkaMessage createKafkaMessage(Event event) {
		return null;
	}

	public Event retreiveEvent(KafkaMessage message) {
		return null;
	}

}
