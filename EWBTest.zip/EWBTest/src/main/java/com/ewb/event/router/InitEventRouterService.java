package com.ewb.event.router;

import com.ewb.config.client.CacheEventTypeKafkaClientMap;

public class InitEventRouterService {
	private CacheEventTypeKafkaClientMap cache;
	private EventRouterFactory eventRouterFactory;

	public InitEventRouterService() {
		super();
	}

	public void intiateMessageRouterFactory() {

	}
}
