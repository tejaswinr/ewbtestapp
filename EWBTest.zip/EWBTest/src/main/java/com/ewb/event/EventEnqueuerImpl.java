package com.ewb.event;

import java.util.concurrent.BlockingQueue;

import com.ewb.common.AbstractEnqueuer;
import com.ewb.event.entity.Event;

public class EventEnqueuerImpl extends AbstractEnqueuer<Event> {

	public EventEnqueuerImpl(BlockingQueue<Event> inboundQueue, int offerTimeout) {
		super(inboundQueue, offerTimeout);
	}

	public EventEnqueuerImpl(BlockingQueue<Event> inboundQueue) {
		super(inboundQueue);
	}

	@Override
	public void enqueue(Event object) {
		// TODO Auto-generated method stub

	}

}
