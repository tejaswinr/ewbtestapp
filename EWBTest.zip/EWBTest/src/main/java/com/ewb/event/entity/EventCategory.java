package com.ewb.event.entity;

public enum EventCategory {

	EXCEPTION,
	WEB_UI
}
