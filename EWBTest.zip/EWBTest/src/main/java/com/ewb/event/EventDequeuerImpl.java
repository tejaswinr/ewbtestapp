package com.ewb.event;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import com.ewb.common.AbstractDequeuer;
import com.ewb.common.Listener;
import com.ewb.event.entity.Event;

public class EventDequeuerImpl extends AbstractDequeuer<Event> implements Runnable {

	private List<Listener<Event>> eventListeners;

	public EventDequeuerImpl(BlockingQueue<Event> outboundQueue, int pollTimeout) {
		super(outboundQueue, pollTimeout);
	}

	public EventDequeuerImpl(BlockingQueue<Event> outboundQueue) {
		super(outboundQueue);
	}

	private void updateEventListeners(Event event) {
		for (Listener<Event> eventListener : eventListeners) {
			eventListener.updateListener(event);
		}
	}

	public void registerEventListener(Listener<Event> listener) {
		if (eventListeners == null) {
			eventListeners = new ArrayList<>();
		}
		eventListeners.add(listener);
	}

	@Override
	public void run() {
		// TODO
		while (true) {
			try {
				Event event = dequeue();
				if (event == null) {
					continue;
				}
				updateEventListeners(event);
			} catch (InterruptedException e) {
				// LOGGER
				e.printStackTrace();
			}
		}

	}
}
