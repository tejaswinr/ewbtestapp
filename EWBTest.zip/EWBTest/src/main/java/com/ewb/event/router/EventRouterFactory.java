package com.ewb.event.router;

import com.ewb.event.entity.EventCategory;
import com.ewb.event.entity.EventType;

public class EventRouterFactory {

	public EventRouter createMessageRouter(EventType eventType, EventCategory eventCategory) {
		return null;
	}
}
