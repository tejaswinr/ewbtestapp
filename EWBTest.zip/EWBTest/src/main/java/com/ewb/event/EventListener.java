package com.ewb.event;

import com.ewb.event.entity.Event;

public interface EventListener {

	public void receiveEvent(Event event);
}
