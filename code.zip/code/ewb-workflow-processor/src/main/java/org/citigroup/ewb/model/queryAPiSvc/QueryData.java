package org.citigroup.ewb.model.queryAPiSvc;

public class QueryData {
	private UpdateAssignee updateAssignee;
	private UpdateStatus updateStatus;

	public UpdateStatus getUpdateStatus() {
		return updateStatus;
	}

	public void setUpdateStatus(UpdateStatus updateStatus) {
		this.updateStatus = updateStatus;
	}

	public UpdateAssignee getUpdateAssignee() {
		return updateAssignee;
	}

	public void setUpdateAssignee(UpdateAssignee updateAssignee) {
		this.updateAssignee = updateAssignee;
	}

}
