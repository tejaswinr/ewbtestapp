package org.citigroup.ewb.model.queryAPiSvc;

import java.util.List;

public class QueryGqlResponse {
	private QueryData data;
	private List<QueryError> errors;

	public QueryData getData() {
		return data;
	}

	public void setData(QueryData data) {
		this.data = data;
	}

	public List<QueryError> getErrors() {
		return errors;
	}

	public void setErrors(List<QueryError> errors) {
		this.errors = errors;
	}

}
