package org.citigroup.ewb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkflowProcessorApplication {

  public static void main(String[] args) {
    SpringApplication.run(WorkflowProcessorApplication.class, args);
  }
}