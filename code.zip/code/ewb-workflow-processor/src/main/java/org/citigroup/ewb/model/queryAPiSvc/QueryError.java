package org.citigroup.ewb.model.queryAPiSvc;

public class QueryError {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
