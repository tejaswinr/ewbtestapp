package org.citigroup.ewb.model.queryAPiSvc;

public class UpdateAssignee {
	private String assignee;
	private String _id;

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

}
