package org.citigroup.ewb.utills;

import java.lang.reflect.Field;

import org.citigroup.ewb.model.guiEventSvc.TradeProcessingException;
import org.citigroup.ewb.model.guiEventSvc.WfEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class ApiSvcQueryGenerator {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ApiSvcQueryGenerator.class);

	public String getApiSvcQuery(WfEvent wfe) throws IllegalArgumentException,
			IllegalAccessException {
		if (wfe.getCoreSystem().equalsIgnoreCase("Trade Processing")) {
			return tpExceptionGuiUpdateQuery(wfe.getExceptionObj());
		} else {
			return null;
		}
	}

	public String tpExceptionGuiUpdateQuery(TradeProcessingException tpe)
			throws IllegalArgumentException, IllegalAccessException {
		String query = null;
		Field[] fields = tpe.getClass().getDeclaredFields();
		for (Field field : fields) {
			field.setAccessible(true);
			Object obj = field.get(tpe);
			if (obj != null && !field.getName().equalsIgnoreCase("id")) {
				query = "{\"query\":\"mutation { update"
						+ StringUtils.capitalize(field.getName()) + "(_id:\\\""
						+ tpe.getId() + "\\\", value:\\\"" + field.get(tpe)
						+ "\\\") {" + field.getName() + ",_id}}\"}";
			}
		}
		return query;
	}
}
