package org.citigroup.ewb.kafka.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.citigroup.ewb.kafka.interaction.Receiver;
import org.citigroup.ewb.model.guiEventSvc.WfEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.AbstractMessageListenerContainer.AckMode;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonDeserializer;

@Configuration
@EnableKafka
public class ReceiverConfig {

	@Value("${kafka.bootstrap-servers}")
	private String bootstrapServers;

	@Bean
	public Map<String, Object> consumerConfigs() {
		Map<String, Object> props = new HashMap<String, Object>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				StringDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				JsonDeserializer.class);
		props.put(ConsumerConfig.CLIENT_ID_CONFIG, "workflow-processor-client");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		return props;
	}

	@Bean
	public ConsumerFactory<String, WfEvent> consumerFactory() {
		 return new DefaultKafkaConsumerFactory<String, WfEvent>(consumerConfigs(),
	    	      new StringDeserializer(), 
	    	      new JsonDeserializer<WfEvent>(WfEvent.class));
	}

	@Bean
	public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, WfEvent>> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, WfEvent> factory = new ConcurrentKafkaListenerContainerFactory<String, WfEvent>();
		factory.setConsumerFactory(consumerFactory());
		factory.setConcurrency(1);
		factory.getContainerProperties().setAckMode(AckMode.MANUAL);
		factory.setBatchListener(false);
		return factory;
	}

	@Bean
	public Receiver receiver() {
		return new Receiver();
	}
}
