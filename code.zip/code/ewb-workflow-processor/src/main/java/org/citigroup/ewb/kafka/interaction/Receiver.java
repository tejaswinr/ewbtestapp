package org.citigroup.ewb.kafka.interaction;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.citigroup.ewb.model.guiEventSvc.WfEvent;
import org.citigroup.ewb.model.queryAPiSvc.QueryGqlResponse;
import org.citigroup.ewb.utills.ApiSvcQueryGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Receiver {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(Receiver.class);

	@Autowired
	public ApiSvcQueryGenerator apiSvcQueryGenerator;

	@Value("${query.api.svc.url}")
	private String queryApiSvcUrl;

	@Value("${changeeventpub.api.svc.url}")
	private String changeEventPubApiSvcUrl;

	@KafkaListener(topics = "${kafka.topic.ewb}", groupId = "${kafka.topic.ewb.groupId}")
	public void receive(ConsumerRecord<Integer, WfEvent> cr, Acknowledgment ack)
			throws IllegalArgumentException, IllegalAccessException {
		LOGGER.info("START");
		try {
			LOGGER.info(
					"received offset='{}' ,partition='{}', topic='{}', type='{}'",
					cr.offset(), cr.partition(), cr.topic(), cr.value()
							.getType());
			if (cr.value().getType().equalsIgnoreCase("update")) {
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.set("Content-Type", "application/json");
				String gqlQuery = apiSvcQueryGenerator.getApiSvcQuery(cr
						.value());
				LOGGER.info(gqlQuery);
				HttpEntity<String> httpEntity = new HttpEntity<String>(
						gqlQuery, httpHeaders);
				RestTemplate restTemplate = new RestTemplate();
				QueryGqlResponse response = restTemplate.postForObject(
						queryApiSvcUrl, httpEntity, QueryGqlResponse.class);
				ObjectMapper mapper = new ObjectMapper();
				String jsonInString = mapper.writeValueAsString(response);
				LOGGER.info("Response from Query API Svc - "
						+ jsonInString);
				HttpEntity<QueryGqlResponse> cepasHttpEntity = new HttpEntity<QueryGqlResponse>(
						response, httpHeaders);
				String res = restTemplate.postForObject(
						changeEventPubApiSvcUrl, cepasHttpEntity, String.class);
				LOGGER.info("Response from change event publisher - " + res);
			}
		} catch (Exception e) {
			LOGGER.error("Error in Workflow processor -" + e.getMessage());
			e.printStackTrace();
		}
		ack.acknowledge();
		LOGGER.info("END");
	}
}
