package org.citigroup.ewb.model.queryAPiSvc;

public class UpdateStatus {
	private String status;
	private String _id;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}
}
