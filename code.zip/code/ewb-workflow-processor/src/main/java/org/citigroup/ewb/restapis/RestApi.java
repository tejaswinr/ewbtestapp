package org.citigroup.ewb.restapis;

import org.citigroup.ewb.kafka.interaction.Sender;
import org.citigroup.ewb.model.guiEventSvc.TradeProcessingException;
import org.citigroup.ewb.model.guiEventSvc.WfEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestApi {

	private static final Logger LOGGER = LoggerFactory.getLogger(RestApi.class);

	@Value("${kafka.topic.ewb}")
	private String topic;

	@Autowired
	public Sender sender;

	@RequestMapping("/produce")
	public String produceToKafka() {
		LOGGER.info("Inside /produce");
		WfEvent wfe = new WfEvent();
		wfe.setCoreSystem("Trade Processing");
		wfe.setType("update");
		TradeProcessingException tpe = new TradeProcessingException();
		tpe.setAssignee("Mark");
		tpe.setId("5a9cfd9278f714bcbfd9c30e");
		wfe.setExceptionObj(tpe);
		try {
				sender.send(topic, "one", wfe);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return "OK";
	}
}
