package ewb;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import com.citigroup.ewb.SpringKafkaApplication;
import com.citigroup.ewb.producer.EwbCoreSender;
import com.citigroup.ewb.producer.SenderConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.Before;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;

/**
 * test avro kafka producer
 * @author zh22901
 *
 */
@DisplayName("A Test case for Kafka producer")
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = SpringKafkaApplication.class)
public class KafkaProducerTest {


    @Mock
    SenderConfig config;

    @Before
    public void setup(){

        config = new SenderConfig();
    }

    @Test
    @DisplayName("send an event to coresystem topic from test")
    public void sendEventTest() {
        String topic = "coresystem";
        Event event = EventGenerator.getNext();
        try {
            Properties props = config.properties();
            Producer<String, Event> producer = new KafkaProducer<String, Event>(props);
            ProducerRecord<String, Event> record = new ProducerRecord<String, Event>("coresystem", "123",event);

            producer.send(record);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
