package ewb;

import com.citigroup.ewb.SpringKafkaApplication;
import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.domain.AvroEventProducer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.concurrent.ExecutionException;

/**
 * test avro kafka producer
 * @author zh22901
 *
 */
@DisplayName("A Test case for Kafka producer")
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = SpringKafkaApplication.class)
public class AvroKafkaProducerTest {

	@Autowired
    AvroEventProducer akp;
	
    @Test
    @DisplayName("send an event to coresystem topic")
    public void sendEventTest() {
    	String topic = "coresystem";
    	Event event = EventGenerator.getNext();
    	try {
			akp.produce(event, topic);
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }	
}
