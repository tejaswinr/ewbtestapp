package ewb;

import com.citigroup.ewb.SpringKafkaApplication;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;

import javax.annotation.PostConstruct;

/**
 * Created by Sunil Yadav on 12/27/2017.
 */
@DisplayName("A Test case for Kafka rest api")
@Configuration
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = SpringKafkaApplication.class)
class KafkaRestApiTests {

    private static WebTestClient client;
    
	@Value("${kafka.baseurl:http://sd-ca1d-dc6f:8082}")
	private String kafkabaseurl;
    
	@BeforeAll
    static void initAll() {
    }

	@PostConstruct
	public void initWeb() {
        System.out.print("Bind server: " + kafkabaseurl);
		client = WebTestClient.bindToServer().baseUrl(kafkabaseurl).build();
	}
	
    @BeforeEach
    void init() {
    }

    @Test
    @DisplayName("Get kafka topics using rest api call 😱")
    public void kafkaTopicsTest() {
    	System.out.print("test kafka topics.\r\n");
    	WebTestClient.BodyContentSpec spec = client.get().uri("/topics").accept(MediaType.APPLICATION_JSON_UTF8)
                .exchange()
                .expectStatus().isOk()
                .expectBody();
   		spec.jsonPath("$[4]").isEqualTo("coresystem");
   		spec.jsonPath("$[14]").isEqualTo("nav");
   		spec.jsonPath("$[20]").isEqualTo("trading");
    }
   
    @AfterEach
    void tearDown() {
    }

    @AfterAll
    static void tearDownAll() {
    }
}
