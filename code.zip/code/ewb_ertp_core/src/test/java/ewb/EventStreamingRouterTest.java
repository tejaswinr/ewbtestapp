package ewb;

import com.citigroup.ewb.SpringKafkaApplication;
import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.domain.AvroEventProducer;
import com.citigroup.ewb.domain.ProcessService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicLong;

@DisplayName("A Test case for Kafka streaming service")
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = SpringKafkaApplication.class)
public class EventStreamingRouterTest {
	
	@Autowired
    AvroEventProducer akp;

	@Autowired 
	private ProcessService processService;

    private void produceAnEvent() {
    	String topic = "coresystem";
    	Event event = EventGenerator.getNext();
    	try {
			akp.produce(event, topic);
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }	
    
    @Test
    @DisplayName("streaming test")
    public void eventStreamingTest() {
    	CompletableFuture<AtomicLong> eventProcessed = this.processService.process();
		try {
			Thread.currentThread().sleep(6000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

    	long preeventnumber=0,eventnumber=0;
    	for (int i=0; i<10; i++) {
	    	try {
				Thread.currentThread().sleep(2000);
				preeventnumber = eventProcessed.get().get(); 

	    	} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	this.produceAnEvent();
	    	try {
				Thread.currentThread().sleep(2000);
				eventnumber = eventProcessed.get().get(); 
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	System.out.print("\r\npreeventnumber: " + preeventnumber);
	    	System.out.print("\r\neventnumber: " + eventnumber);
			assert(eventnumber-preeventnumber >= 0);
    	}
//    	this.processService.stop();
    }	    
}
