package ewb;

public class SpringKafkaSenderTest {

//    private static final Logger LOGGER = LoggerFactory.getLogger(SpringKafkaSenderTest.class);
//
//    private static String SENDER_TOPIC = "sender.t";
//
//    @Autowired
//    private EwbCoreSender sender;
//
//    private KafkaMessageListenerContainer<String, Event> container;
//
//    private BlockingQueue<ConsumerRecord<String, Event>> records;
//
//    @ClassRule
//    public static KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, SENDER_TOPIC);
//
//    @Before
//    public void setUp() throws Exception {
//        // set up the Kafka consumer properties
//        Map<String, Object> consumerProperties =
//                KafkaTestUtils.consumerProps("sender", "false", embeddedKafka);
//
//        // create a Kafka consumer factor
//        DefaultKafkaConsumerFactory<String, Event> consumerFactory =
//                new DefaultKafkaConsumerFactory<String, Event>(consumerProperties);
//
//        // set the topic that needs to be consumed
//        ContainerProperties containerProperties = new ContainerProperties(SENDER_TOPIC);
//
//        // create a Kafka MessageListenerContainer
//        container = new KafkaMessageListenerContainer<>(consumerFactory, containerProperties);
//
//        // create a thread safe queue to store the received message
//        records = new LinkedBlockingQueue<>();
//
//        // setup a Kafka message listener
//        container.setupMessageListener(new MessageListener<String, Event>() {
//            @Override
//            public void onMessage(ConsumerRecord<String, Event> record) {
//                LOGGER.debug("test-listener received message='{}'", record.toString());
//                records.add(record);
//            }
//        });
//
//        // start the container and underlying message listener
//        container.start();
//
//        // wait until the container has the required number of assigned partitions
//        ContainerTestUtils.waitForAssignment(container, embeddedKafka.getPartitionsPerTopic());
//    }
//
//    @After
//    public void tearDown() {
//        // stop the container
//        container.stop();
//    }
//
//    @Test
//    public void testSend() throws InterruptedException {
//        // send the message
//        Event event= EventGenerator.getNext();
//        String greeting = "Hello Spring Kafka Sender!";
//        SenderConfig config= new SenderConfig();
//        Properties props = config.properties();
//        Producer<String, Event> producer = new KafkaProducer<String, Event>(props);
//        ProducerRecord<String, Event> record = new ProducerRecord<String, Event>(SENDER_TOPIC, "1",event);
//        //sender.send(SENDER_TOPIC, greeting);
//        producer.send(record);
//        // check that the message was received
//        ConsumerRecord<String, Event> received = records.poll(10, TimeUnit.SECONDS);
//        // Hamcrest Matchers to check the value
//        assertThat(received, hasValue(event));
//        // AssertJ Condition to check the key
//        assertThat(received).has(key("1"));
//    }
}
