package com.citigroup.ewb.domain;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.common.util.EventTransfer;
import com.citigroup.ewb.config.KafkaProducerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

/**
 * The avro event producer is internally using a KafkaProducer to produce event message to a specified topic.
 * @author zh22901
 * @see KafkaProducerConfig
 */

@Component
public class AvroEventProducer {
	
	private static final Logger logger = LogManager.getLogger(AvroEventProducer.class);
	
	@Autowired
    KafkaProducerConfig config; // Configuration for Apache Kafka Producer

    Producer<String, Event> producer;
	
    public AvroEventProducer() {
    }

    /**
     * @startuml
     * SpringBeanPostProcessor -> AvroEventProducer : initialize
     * AvroEventProducer -> KafkaProducer : new KafkaProducer(props)
     * @enduml
     *
     */

    @PostConstruct
    /**
     * initialize the avro event producer. It includes a kafkaProducer instance for sending messages out to a topic. 
     */
    public void initialize() {
    	
    	logger.info("Initialize Avro event producer with properties as below");
        Properties props = config.properties();
    	logger.info(props.toString());
        producer = new KafkaProducer<String, Event>(props);
    }
    
    /**
     * Send a number of events to a kafka topic
     * @param events : Number of events to be sent.
     * @param topic : a kafka topic used to store the events passed in
     * @throws ExecutionException
     * @throws InterruptedException
     */
	public void produce(long events, String topic) throws ExecutionException, InterruptedException {

        for (long nEvents = 0; nEvents < events; nEvents++) {
        	Event event = EventGenerator.getNext(); // simulator of event generator to generate event data
		// create a new ProducerRecord instance required by Kafka Producer
	       ProducerRecord<String, Event> record = new ProducerRecord<String, Event>(topic, event.getTransactionId().toString(), event);
		// send the record out. Here get() method is used to make a blocked call.
	       producer.send(record).get();
        }
	}

	/**
	 * @startuml
	 * AvroEventProducer -> ProducerRecord : record = new ProducerRecord
	 * AvroEventProducer -> KafkaProducer : send(record)
	 * @enduml
	 */
	
	/**
	 * Use KafkaProducer to send an event to a kafka topic. 
	 * @param event : event data to be sent. 
	 * @param topic : a kafka topic used to store the event passed in 
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	public RecordMetadata produce(Event event, String topic) throws ExecutionException, InterruptedException {

		// create a new ProducerRecord instance required by Kafka Producer
	       System.out.print(EventTransfer.debugEvent(event, null));

	       ProducerRecord<String, Event> record = new ProducerRecord<String, Event>(topic, event.getTransactionId().toString(), event);
		// send the record out. Here get() method is used to make a blocked call.
	       System.out.print("Sending event...\r\n"); 
	       RecordMetadata rm =  producer.send(record).get();
	       System.out.print("successfully send event.\r\n"); 
	       return rm;

	}
	
}
