/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.workflow.models;

/**
 * @author gs48329
 *
 */
public class WFEventError {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
