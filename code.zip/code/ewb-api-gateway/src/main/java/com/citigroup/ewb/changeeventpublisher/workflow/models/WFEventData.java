/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.workflow.models;


/**
 * @author gs48329
 *
 */
public class WFEventData {
	private WFEventUpdateAssignee updateAssignee;

	public WFEventUpdateAssignee getUpdateAssignee() {
		return updateAssignee;
	}

	public void setUpdateAssignee(WFEventUpdateAssignee updateAssignee) {
		this.updateAssignee = updateAssignee;
	}

}
