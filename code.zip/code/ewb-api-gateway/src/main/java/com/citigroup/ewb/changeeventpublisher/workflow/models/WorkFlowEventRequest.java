/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.workflow.models;

import java.util.List;

/**
 * @author gs48329
 *
 */
public class WorkFlowEventRequest {
	
	private WFEventData data;
	private List<WFEventError> errors;

	public WFEventData getData() {
		return data;
	}

	public void setData(WFEventData data) {
		this.data = data;
	}

	public List<WFEventError> getErrors() {
		return errors;
	}

	public void setErrors(List<WFEventError> errors) {
		this.errors = errors;
	}

	@Override
	public String toString() {
		return "WorkFlowEventRequest [data=" + data + ", errors=" + errors
				+ "]";
	}

}
