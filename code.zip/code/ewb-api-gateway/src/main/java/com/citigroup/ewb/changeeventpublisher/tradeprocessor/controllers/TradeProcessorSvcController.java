/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.tradeprocessor.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citigroup.ewb.changeeventpublisher.tradeprocessor.models.TradeProcessingException;
import com.citigroup.ewb.changeeventpublisher.tradeprocessor.models.TradeStateEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author gs48329
 *
 */
@RestController
@RequestMapping("/tpexception/newexceptionevent")
public class TradeProcessorSvcController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(TradeProcessorSvcController.class);

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@RequestMapping(method = RequestMethod.POST)
	public String createTPException(
			@RequestBody TradeProcessingException tpException)
			throws MessagingException, JsonProcessingException {

		if (tpException != null) {
			this.simpMessagingTemplate.convertAndSend("/changeevent/newexception",
					new ObjectMapper().writeValueAsString(tpException));
			LOGGER.info("Trade Processor service, send new exception: "
					+ tpException.toString());
			sendEventToTradeState(tpException);
		}

		return "success";
	}
	
	public void sendEventToTradeState(TradeProcessingException tpException) throws MessagingException, JsonProcessingException {
		TradeStateEvent tsEvent = new TradeStateEvent();
		tsEvent.setFirmCode(tpException.getFirmCode());
		tsEvent.setTradeId(tpException.getAllocationId());
		tsEvent.setBlockId(tpException.getBlockExternalReferenceId());
		tsEvent.setExceptionSource(tpException.getExceptionCategory());
		tsEvent.setAssetClass(tpException.getAssetClass());
		this.simpMessagingTemplate.convertAndSend("/changeevent/tradestate",
				new ObjectMapper().writeValueAsString(tsEvent));
		LOGGER.info("Trade Processor service, send new trade state: "
				+ tsEvent.toString());
	}

}
