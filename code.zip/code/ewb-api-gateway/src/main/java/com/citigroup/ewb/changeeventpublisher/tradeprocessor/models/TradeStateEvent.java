/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.tradeprocessor.models;

/**
 * @author gs48329
 *
 */
public class TradeStateEvent {
	
	private String firmCode;
	private String tradeId;
	private String blockId;
	private String assetClass;
	private String fund;
	private String exceptionSource;

	public String getFirmCode() {
		return firmCode;
	}

	public void setFirmCode(String firmCode) {
		this.firmCode = firmCode;
	}

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public String getBlockId() {
		return blockId;
	}

	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getFund() {
		return fund;
	}

	public void setFund(String fund) {
		this.fund = fund;
	}

	public String getExceptionSource() {
		return exceptionSource;
	}

	public void setExceptionSource(String exceptionSource) {
		this.exceptionSource = exceptionSource;
	}

	@Override
	public String toString() {
		return "TradeStateEvent [firmCode=" + firmCode + ", tradeId=" + tradeId
				+ ", blockId=" + blockId + ", assetClass=" + assetClass
				+ ", fund=" + fund + ", exceptionSource=" + exceptionSource
				+ "]";
	}
}
