/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.tradeprocessor.models;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author gs48329
 *
 */
public class TradeProcessingException {
	private String coreSystem;
	private String exceptionCategory;
	private String errorCategory;
	private String errorDescription;
	private String severity;
	private String source;
	private String status;
	private Date createdDate;
	private Date updatedDate;
	private String assignee;
	private String transactionId;
	private String firmCode;
	private String assetClass;
	private String assetTypeCode;
	private String portfolioCode;
	private String allocationId;
	private BigDecimal quantity;
	private String custodianAccount;
	private String createdBy;
	private Date tradeReceivedDate;
	private String filePath;
	private String fileType;
	private String executingBroker;
	private String batchId;
	private String remediationStep;
	private String blockExternalReferenceId;

	public String getCoreSystem() {
		return coreSystem;
	}

	public void setCoreSystem(String coreSystem) {
		this.coreSystem = coreSystem;
	}

	public String getExceptionCategory() {
		return exceptionCategory;
	}

	public void setExceptionCategory(String exceptionCategory) {
		this.exceptionCategory = exceptionCategory;
	}

	public String getErrorCategory() {
		return errorCategory;
	}

	public void setErrorCategory(String errorCategory) {
		this.errorCategory = errorCategory;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getFirmCode() {
		return firmCode;
	}

	public void setFirmCode(String firmCode) {
		this.firmCode = firmCode;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getAssetTypeCode() {
		return assetTypeCode;
	}

	public void setAssetTypeCode(String assetTypeCode) {
		this.assetTypeCode = assetTypeCode;
	}

	public String getPortfolioCode() {
		return portfolioCode;
	}

	public void setPortfolioCode(String portfolioCode) {
		this.portfolioCode = portfolioCode;
	}

	public String getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(String allocationId) {
		this.allocationId = allocationId;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public String getCustodianAccount() {
		return custodianAccount;
	}

	public void setCustodianAccount(String custodianAccount) {
		this.custodianAccount = custodianAccount;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getTradeReceivedDate() {
		return tradeReceivedDate;
	}

	public void setTradeReceivedDate(Date tradeReceivedDate) {
		this.tradeReceivedDate = tradeReceivedDate;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getExecutingBroker() {
		return executingBroker;
	}

	public void setExecutingBroker(String executingBroker) {
		this.executingBroker = executingBroker;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getRemediationStep() {
		return remediationStep;
	}

	public void setRemediationStep(String remediationStep) {
		this.remediationStep = remediationStep;
	}

	public String getBlockExternalReferenceId() {
		return blockExternalReferenceId;
	}

	public void setBlockExternalReferenceId(String blockExternalReferenceId) {
		this.blockExternalReferenceId = blockExternalReferenceId;
	}

	@Override
	public String toString() {
		return "TradeProcessingException [coreSystem=" + coreSystem
				+ ", exceptionCategory=" + exceptionCategory
				+ ", errorCategory=" + errorCategory + ", errorDescription="
				+ errorDescription + ", severity=" + severity + ", source="
				+ source + ", status=" + status + ", createdDate="
				+ createdDate + ", updatedDate=" + updatedDate + ", assignee="
				+ assignee + ", transactionId=" + transactionId + ", firmCode="
				+ firmCode + ", assetClass=" + assetClass + ", assetTypeCode="
				+ assetTypeCode + ", portfolioCode=" + portfolioCode
				+ ", allocationId=" + allocationId + ", quantity=" + quantity
				+ ", custodianAccount=" + custodianAccount + ", createdBy="
				+ createdBy + ", tradeReceivedDate=" + tradeReceivedDate
				+ ", filePath=" + filePath + ", fileType=" + fileType
				+ ", executingBroker=" + executingBroker + ", batchId="
				+ batchId + ", remediationStep=" + remediationStep
				+ ", blockExternalReferenceId=" + blockExternalReferenceId
				+ "]";
	}

}
