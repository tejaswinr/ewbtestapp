/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.workflow.models;

/**
 * @author gs48329
 *
 */
public class WFEventUpdateAssignee {
	private String assignee;

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
}
