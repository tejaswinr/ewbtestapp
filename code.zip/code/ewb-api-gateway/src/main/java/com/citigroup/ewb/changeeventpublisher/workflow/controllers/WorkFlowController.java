/**
 * 
 */
package com.citigroup.ewb.changeeventpublisher.workflow.controllers;

import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citigroup.ewb.changeeventpublisher.guieventsvc.controllers.GuiEventSvcController;
import com.citigroup.ewb.changeeventpublisher.workflow.models.WorkFlowEventRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author gs48329
 *
 */
@RestController
@RequestMapping("/tpexception/workflowevent")
public class WorkFlowController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(WorkFlowController.class);

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@RequestMapping(method = RequestMethod.POST)
	public String guiEvent(@RequestBody WorkFlowEventRequest wfEventBody)
			throws MessagingException, JsonProcessingException {
		if (wfEventBody != null && wfEventBody.getData() != null) {
			Field[] fields = wfEventBody.getData().getClass()
					.getDeclaredFields();

			for (Field field : fields) {
				field.setAccessible(true);
				this.simpMessagingTemplate.convertAndSend(
						"/socket/" + field.getName(), new ObjectMapper()
								.writeValueAsString(wfEventBody.getData()));
			}
			LOGGER.info("WorkFlow Event service: " + wfEventBody.toString());
		}
		return "OK";
	}
}
