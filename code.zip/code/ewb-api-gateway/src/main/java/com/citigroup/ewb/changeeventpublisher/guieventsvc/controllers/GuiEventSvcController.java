package com.citigroup.ewb.changeeventpublisher.guieventsvc.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.citigroup.ewb.changeeventpublisher.guieventsvc.models.GuiEvent;



@RestController
@RequestMapping("/tpexception/guievent")
public class GuiEventSvcController {
	private static final Logger LOGGER = LoggerFactory.getLogger(GuiEventSvcController.class);

	@Value("${gui.event.svc.url}")
	private String guiEventSvcUrl;

	@RequestMapping(method = RequestMethod.POST)
	public String guiEvent(@RequestBody GuiEvent guiEvent) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");
		HttpEntity<GuiEvent> httpEntity = new HttpEntity<GuiEvent>(guiEvent,
				httpHeaders);
		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject(guiEventSvcUrl,
				httpEntity, String.class);
		LOGGER.info("GUI Event Service :"+ guiEvent.toString());
		return response;
	}
}
