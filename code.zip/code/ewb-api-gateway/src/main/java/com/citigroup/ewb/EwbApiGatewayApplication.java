package com.citigroup.ewb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EwbApiGatewayApplication {

  public static void main(String[] args) {
    SpringApplication.run(EwbApiGatewayApplication.class, args);
  }
}