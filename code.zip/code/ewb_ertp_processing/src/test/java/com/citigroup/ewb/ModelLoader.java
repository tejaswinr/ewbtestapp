package com.citigroup.ewb;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.citigroup.ewb.model.AnalysisModel;

public class ModelLoader {
	
	public static String modelfiledir = "C:\\Users\\ZH22901\\workspace\\EWB\\ewb_ertp_processing\\src\\test\\files\\models"; 
	
	public static void main(String[] args) {
		ModelLoader obj = new ModelLoader();
		AnalysisModel m = obj.load(modelfiledir, 1);
	}

	private void run() {	
		try
		{
			ObjectMapper mapper = new ObjectMapper();
	
			AnalysisModel model = AnalysisModel.generateSampleModel();	
			String modelfilename = modelfiledir + "\\models\\model-" + String.valueOf(1) + ".txt";			
			// Convert object to JSON string and save into a file directly
			mapper.writeValue(new File(modelfilename), model);
	
			// Convert object to JSON string
			String jsonInString = mapper.writeValueAsString(model);
			System.out.println(jsonInString);
			
			// Convert object to JSON string and pretty print
			jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(model);
			System.out.println(jsonInString);
			
		} catch (JsonGenerationException ex) {
			ex.printStackTrace();
		} catch (JsonMappingException ex1) {
			ex1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static AnalysisModel load(String basedir, int modelid) {
		String modelfile = basedir + "\\models\\model-" + String.valueOf(modelid) + ".txt";
		AnalysisModel model = new AnalysisModel();
		try
		{
			ObjectMapper mapper = new ObjectMapper();
	
	
			// Convert object to JSON string and save into a file directly
			model = mapper.readValue(new File(modelfile), model.getClass());
			// Convert object to JSON string
			String jsonInString = mapper.writeValueAsString(model);
			System.out.println(jsonInString);
			
			// Convert object to JSON string and pretty print
			jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(model);
			System.out.println(jsonInString);
			
		} catch (JsonGenerationException ex) {
			ex.printStackTrace();
		} catch (JsonMappingException ex1) {
			ex1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return model;          
	}
}
