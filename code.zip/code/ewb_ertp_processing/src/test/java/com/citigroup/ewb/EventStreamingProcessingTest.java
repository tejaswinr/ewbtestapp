package com.citigroup.ewb;

import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlContext;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.JexlExpression;
import org.apache.commons.jexl3.MapContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.concurrent.ThreadLocalRandom;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.config.ApplicationConfig;
import com.citigroup.ewb.domain.AvroEventProducer;
import com.citigroup.ewb.domain.components.C_Analysis;
import com.citigroup.ewb.domain.rules.FieldRules;
import com.citigroup.ewb.domain.ProcessService;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.ProfileUtil;


@DisplayName("A Test case for processing service")
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = EventStreamingProcessingTest.class)
@ComponentScan("com.citigroup")
public class EventStreamingProcessingTest {
	
	@Autowired
	AvroEventProducer akp;

	@Autowired
	C_Analysis analysisEngine;
	
	@Autowired
	ApplicationConfig config;
	
	Random r = new Random(1000);

	@Autowired 
	private ProcessService processService; 

    private void produceEvents() {
    	String topic = "trading";

    	// nextInt is normally exclusive of the top value,
    	// so add 1 to make it inclusive
    	int randomNum = ThreadLocalRandom.current().nextInt(5, 10);
    	
    	for (int i=0; i< randomNum; i++) {
	    	Event event = EventGenerator.getNext();
	    	try {
				akp.produce(event, topic);
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	
    }	
    
    @Test
    @DisplayName("test TotalKeyValueParser")
    public void testTotalKeyValueParser() {
    	String basedir = config.getBasedir();
    	AnalysisModel model = ModelLoader.load(basedir, 1);
    	analysisEngine.setModel(model);
    	try {
    		analysisEngine.initialize();
    	} catch (Exception e) {
    		e.printStackTrace();
    	} 	
    	String key = "total#KAMES#At Risk##";
    	String value = "2";
    	String name = "TPE.stage.Statistic";
    	MeasureModel mm = model.getMeasureModel(name);
    	Map row = ProfileUtil.parseTotalKeyValue(mm, key, value);
    	System.out.print(row.toString()+"\n");
  //  	assert(row.toString().equals("{STATUS=At Risk, FIRM_CODE=KAMES, VALUE=2}"));
    }
    
    @Test
    @DisplayName("test KeyValueParser")
    public void testKeyValueParser() {
    	String basedir = config.getBasedir();
    	AnalysisModel model = ModelLoader.load(basedir, 1);
    	analysisEngine.setModel(model);
    	try {
    		analysisEngine.initialize();
    	} catch (Exception e) {
    		e.printStackTrace();
    	} 	
    	String key = "KAMES#Work On Progress##1509581640000";
    	String value = "2";
    	String name = "TPE.assetclass.Statistic";
    	MeasureModel mm = model.getMeasureModel(name);
    	Map row = ProfileUtil.parseKeyValue(mm, key, value);
    	System.out.print(row.toString()+"\n");
    }    
    
    @Test
    @DisplayName("test jexl expression engine")
    public void testJEXL() {
        // Create or retrieve an engine
        JexlEngine jexl = new JexlBuilder().create();
        
        // Create an expression
        String jexlExp = "(120.0-($Event.profileTime - $Event.createdDate)/1000.0/60.0)/60.0";
        JexlExpression e = jexl.createExpression( jexlExp );
        
        // Create a context and add data
        JexlContext jc = new MapContext();
        System.out.print("evaluate " + jexlExp + " = ");
        jc.set("$Event.createdDate", 10000L );
        jc.set("$Event.profileTime", 9000L );
        // Now evaluate the expression, getting the result
        Object o = e.evaluate(jc);
        System.out.print(o.toString()+"\n");
        
        String jexlExp1 = "\"new\"";
        JexlExpression e1 = jexl.createExpression( jexlExp1 );
        Object o1 = e1.evaluate(jc);
        System.out.print(o1.toString()+"\n");
        
    }    
    /**
     * https://commons.apache.org/proper/commons-jexl/apidocs/org/apache/commons/jexl3/package-summary.html
     */
    @Test
    @DisplayName("test function on jexl expression engine")
    public void testJEXLFunction() {
    	Map<String, Object> funcs = new HashMap<String, Object>();
    	String fieldRule = config.getFieldRule();
    	FieldRules rules = null;
		try {
			rules = (FieldRules)Class.forName(fieldRule).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        funcs.put("rules", rules);
        JexlEngine jexl = new JexlBuilder().namespaces(funcs).create();

        Event event = EventGenerator.getNext();
        JexlContext jc = new MapContext();
        jc.set("$Event", event);

        JexlExpression e = jexl.createExpression("rules:r_field_severity($Event)");
        Object o = e.evaluate(jc);
        System.out.print(o.toString()+"\n");
    }

/*    @Test
    @DisplayName("streaming test")
    public void eventStreamingTest() {
    	String basedir = config.getBasedir();
    	AnalysisModel model = ModelLoader.load(basedir, 1);
    	analysisEngine.setModel(model);
    	try {
    		analysisEngine.initialize();
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	CompletableFuture<AtomicLong> eventProcessed = this.processService.process();
		try {
			Thread.currentThread().sleep(6000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

    	long preeventnumber=0,eventnumber=0;
    	for (int i=0; i<10; i++) {
	    	try {
				Thread.currentThread().sleep(2000);
				preeventnumber = eventProcessed.get().get(); 

	    	} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	this.produceEvents();
	    	try {
				Thread.currentThread().sleep(2000);
				eventnumber = eventProcessed.get().get(); 
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	System.out.print("\r\npreeventnumber: " + preeventnumber);
	    	System.out.print("\r\neventnumber: " + eventnumber);
			assert(eventnumber-preeventnumber >= 0);
    	}
//    	this.processService.stop();
    }	    */
}
