var myList = [
  { "name": "abc", "age": 50 },
  { "age": "25", "hobby": "swimming" },
  { "name": "xyz", "hobby": "programming" }
];
var getJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status === 200) {
        callback(null, xhr.response);
      } else {
        callback(status, xhr.response);
      }
    };
    xhr.send();
};

// Builds the HTML Table out of myList.
function buildHtmlTable(selector) {
  var url = $("#URL").val();
  getJSON(url, function(err, data) {
	var jdata = JSON.stringify(data)
	var innerlist = $.parseJSON(jdata);
	if (err !== null) innerlist = myList;
	var columns = addAllColumnHeaders(innerlist, selector);
	for (var i = 0; i < innerlist.length; i++) {
		var row$ = $('<tr/>');
		for (var colIndex = 0; colIndex < columns.length; colIndex++) {
			var cellValue = innerlist[i][columns[colIndex]];
			if (cellValue == null) cellValue = "";
			row$.append($('<td/>').html(cellValue));
			}
		$(selector).append(row$);
	 }
 })
}

// Adds a header row to the table and returns the set of columns.
// Need to do union of keys from all records as some records may not contain
// all records.
function addAllColumnHeaders(myList, selector) {
  var columnSet = [];
  var headerTr$ = $('<tr/>');

  for (var i = 0; i < myList.length; i++) {
    var rowHash = myList[i];
    for (var key in rowHash) {
      if ($.inArray(key, columnSet) == -1) {
        columnSet.push(key);
        headerTr$.append($('<th/>').html(key));
      }
    }
  }
  $(selector).append(headerTr$);

  return columnSet;
}


$(function () {
    $("form").on('submit', function (e) {
        e.preventDefault();
    });

    $( "#send" ).click(function() { buildHtmlTable('#excelDataTable'); });
});