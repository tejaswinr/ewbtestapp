// Builds the HTML Table out of myList.
function buildHtmlTable(selector) {
	HttpSession sessionsa = request.getSession(false);
	String user = (String) sessionsa.getAttribute("user");
	String location = (String) sessionsa.getAttribute("location");
	
	var jdata = JSON.stringify(data)
	var innerlist = $.parseJSON(jdata);
	if (err !== null) innerlist = myList;
	var columns = addAllColumnHeaders(innerlist, selector);
	
	for (var i = 0; i < innerlist.length; i++) {
		var row$ = $('<tr/>');
		for (var colIndex = 0; colIndex < columns.length; colIndex++) {
			var cellValue = innerlist[i][columns[colIndex]];
			if (cellValue == null) cellValue = "";
			row$.append($('<td/>').html(cellValue));
			}
		$(selector).append(row$);
	 }
 )
}

// Adds a header row to the table and returns the set of columns.
// Need to do union of keys from all records as some records may not contain
// all records.
function addAllColumnHeaders(myList, selector) {
  var columnSet = [];
  var headerTr$ = $('<tr/>');

  for (var i = 0; i < myList.length; i++) {
    var rowHash = myList[i];
    for (var key in rowHash) {
      if ($.inArray(key, columnSet) == -1) {
        columnSet.push(key);
        headerTr$.append($('<th/>').html(key));
      }
    }
  }
  $(selector).append(headerTr$);

  return columnSet;
}