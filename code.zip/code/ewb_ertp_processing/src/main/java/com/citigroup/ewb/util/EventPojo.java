package com.citigroup.ewb.util;

import org.json.JSONObject;

import com.citigroup.ewb.avro.Event;

public class EventPojo {
	  /** Core system */
	  String coreSystem;

	  /** Transcation date */
	  long createdDate;
	  /** Transcation date */
	  long updatedDate;
	  /** Comments on the trade transcation */
	  long BatchId;
	  /** EXECUTING_BROKER */
	  String executingBroker;
	  /** ERROR_DESCRIPTION */
	  String errorDescription;
	  /** EXCEPTION_CATEGORY */
	  String exceptionCategory;
	  /** ERROR_CATEGORY */
	  String errorCategory;
	  /** Source of the execption  */
	  String source;
	  /** BLOCK_EXTERNAL_REFERENCE_ID */
	  String blockExternalReferenceId;
	  /** Transcation ID for the trade */
	  long transactionId;
	  /** Firm code of the trade */
	  String firmCode;
	  /** Asset class of the security */
	  String assetClass;
	  /** ASSET_TYPE_CODE */
	  String assetTypeCode;
	  /** portfolio code */
	  String portfolioCode;
	  /** ALLOCATION_ID */
	  String allocationId;
	  /** Quantity of the trade */
	  int quantity;
	  /** Custodian account */
	  String custodianAccount;
	  /** FILE_PATH */
	  String filePath;
	  /** FILE_TYPE */
	  String fileType;
	  /** maker of the transcation */
	  String createdBy;
	  /** severity : rule generated field*/
	  String severity;
	  /** aging : rule generated field*/
	  int aging;
	  /** status : rule generated field*/
	  String status;
	  
	  public EventPojo() {}
	  
	  public void importEvent(Event e) {
		  this.BatchId = e.getBatchId();
		  this.blockExternalReferenceId = e.getBlockExternalReferenceId()==null?null:e.getBlockExternalReferenceId().toString();
		  this.createdDate = e.getCreatedDate();
		  this.updatedDate = e.getUpdatedDate();
		  this.errorCategory = e.getErrorCategory()==null?null:e.getErrorCategory().toString();
		  this.errorDescription = e.getErrorDescription()==null?null:e.getErrorDescription().toString();
		  this.exceptionCategory = e.getExceptionCategory()==null?null:e.getExceptionCategory().toString();
		  this.executingBroker = e.getExecutingBroker()==null?null:e.getExecutingBroker().toString();
		  this.setAllocationId(e.getAllocationId()== null ? null : e.getAllocationId().toString());
		  this.setAssetClass(e.getAssetClass() == null ? null : e.getAssetClass().toString());
		  this.setAssetTypeCode(e.getAssetTypeCode() == null ? null : e.getAssetTypeCode().toString());
		  this.setCreatedBy(e.getCreatedBy() == null ? null : e.getCreatedBy().toString());
		  this.setCustodianAccount(e.getCustodianAccount() == null? null : e.getCustodianAccount().toString());
		  this.setFilePath(e.getFilePath() == null ? null : e.getFilePath().toString());
		  this.setFileType(e.getFileType() == null ? null : e.getFileType().toString());
		  this.setFirmCode(e.getFirmCode() == null ? null : e.getFirmCode().toString());
		  this.setPortfolioCode(e.getPortfolioCode() == null ? null : e.getPortfolioCode().toString());
		  this.setQuantity(e.getQuantity());
		  this.setTransactionId(e.getTransactionId());
		  if (e.getProfile()!=null)
			  this.retrieveRuleGeneratedFields(e.getProfile().toString());
	  }
	  
	  /**
	   * Gets the value of the 'createdDate' field.
	   * @return Transcation date
	   */
	  public java.lang.Long getCreatedDate() {
	    return createdDate;
	  }

	  /**
	   * Sets the value of the 'createdDate' field.
	   * Transcation date
	   * @param value the value to set.
	   */
	  public void setCreatedDate(java.lang.Long value) {
	    this.createdDate = value;
	  }

	  /**
	   * Gets the value of the 'createdDate' field.
	   * @return Transcation date
	   */
	  public java.lang.Long getUpdatedDate() {
	    return updatedDate;
	  }

	  /**
	   * Sets the value of the 'createdDate' field.
	   * Transcation date
	   * @param value the value to set.
	   */
	  public void setUpdatedDate(java.lang.Long value) {
	    this.updatedDate = value;
	  }

	  /**
	   * Gets the value of the 'BatchId' field.
	   * @return Batch id of the trade
	   */
	  public java.lang.Long getBatchId() {
	    return BatchId;
	  }

	  /**
	   * Sets the value of the 'BatchId' field.
	   * Batch id of the trade
	   * @param value the value to set.
	   */
	  public void setBatchId(java.lang.Long value) {
	    this.BatchId = value;
	  }

	  /**
	   * Gets the value of the 'executingBroker' field.
	   * @return EXECUTING_BROKER
	   */
	  public String getExecutingBroker() {
	    return executingBroker;
	  }

	  /**
	   * Sets the value of the 'executingBroker' field.
	   * EXECUTING_BROKER
	   * @param value the value to set.
	   */
	  public void setExecutingBroker(String value) {
	    this.executingBroker = value;
	  }
	  /**
	   * Gets the value of the 'sourec' field.
	   * @return Source
	   */
	  public String getSource() {
	    return source;
	  }

	  /**
	   * Sets the value of the 'Source' field.
	   * Source
	   * @param value the value to set.
	   */
	  public void setSource(String value) {
	    this.source = value;
	  }

	  /**
	   * Gets the value of the 'coreSystem' field.
	   * @return coreSystem
	   */
	  public String getCoreSystem() {
	    return this.coreSystem;
	  }

	  /**
	   * Sets the value of the 'coreSystem' field.
	   * corySystem
	   * @param value the value to set.
	   */
	  public void setCoreSystem(String value) {
	    this.coreSystem = value;
	  }
	  
	  /**
	   * Gets the value of the 'errorDescription' field.
	   * @return ERROR_DESCRIPTION
	   */
	  public String getErrorDescription() {
	    return errorDescription;
	  }

	  /**
	   * Sets the value of the 'errorDescription' field.
	   * ERROR_DESCRIPTION
	   * @param value the value to set.
	   */
	  public void setErrorDescription(String value) {
	    this.errorDescription = value;
	  }

	  /**
	   * Gets the value of the 'exceptionCategory' field.
	   * @return EXCEPTION_CATEGORY
	   */
	  public String getExceptionCategory() {
	    return exceptionCategory;
	  }

	  /**
	   * Sets the value of the 'exceptionCategory' field.
	   * EXCEPTION_CATEGORY
	   * @param value the value to set.
	   */
	  public void setExceptionCategory(String value) {
	    this.exceptionCategory = value;
	  }

	  /**
	   * Gets the value of the 'errorCategory' field.
	   * @return ERROR_CATEGORY
	   */
	  public String getErrorCategory() {
	    return errorCategory;
	  }

	  /**
	   * Sets the value of the 'errorCategory' field.
	   * ERROR_CATEGORY
	   * @param value the value to set.
	   */
	  public void setErrorCategory(String value) {
	    this.errorCategory = value;
	  }

	  /**
	   * Gets the value of the 'blockExternalReferenceId' field.
	   * @return BLOCK_EXTERNAL_REFERENCE_ID
	   */
	  public String getBlockExternalReferenceId() {
	    return blockExternalReferenceId;
	  }

	  /**
	   * Sets the value of the 'blockExternalReferenceId' field.
	   * BLOCK_EXTERNAL_REFERENCE_ID
	   * @param value the value to set.
	   */
	  public void setBlockExternalReferenceId(String value) {
	    this.blockExternalReferenceId = value;
	  }

	  /**
	   * Gets the value of the 'transactionId' field.
	   * @return Transcation ID for the trade
	   */
	  public java.lang.Long getTransactionId() {
	    return transactionId;
	  }

	  /**
	   * Sets the value of the 'transactionId' field.
	   * Transcation ID for the trade
	   * @param value the value to set.
	   */
	  public void setTransactionId(java.lang.Long value) {
	    this.transactionId = value;
	  }

	  /**
	   * Gets the value of the 'quantity' field.
	   * @return Quantity of the trade
	   */
	  public java.lang.Integer getQuantity() {
	    return quantity;
	  }

	  /**
	   * Sets the value of the 'quantity' field.
	   * Quantity of the trade
	   * @param value the value to set.
	   */
	  public void setQuantity(java.lang.Integer value) {
	    this.quantity = value;
	  }

	  /**
	   * Gets the value of the 'custodianAccount' field.
	   * @return Custodian account
	   */
	  public String getCustodianAccount() {
	    return custodianAccount;
	  }

	  /**
	   * Sets the value of the 'custodianAccount' field.
	   * Custodian account
	   * @param value the value to set.
	   */
	  public void setCustodianAccount(String value) {
	    this.custodianAccount = value;
	  }


	  /**
	   * Gets the value of the 'assetClass' field.
	   * @return Asset class of the security
	   */
	  public String getAssetClass() {
	    return assetClass;
	  }

	  /**
	   * Sets the value of the 'assetClass' field.
	   * Asset class of the security
	   * @param value the value to set.
	   */
	  public void setAssetClass(String value) {
	    this.assetClass = value;
	  }

	  /**
	   * Gets the value of the 'allocationId' field.
	   * @return ALLOCATION_ID
	   */
	  public String getAllocationId() {
	    return allocationId;
	  }

	  /**
	   * Sets the value of the 'allocationId' field.
	   * ALLOCATION_ID
	   * @param value the value to set.
	   */
	  public void setAllocationId(String value) {
	    this.allocationId = value;
	  }

	  /**
	   * Gets the value of the 'createdBy' field.
	   * @return maker of the transcation
	   */
	  public String getCreatedBy() {
	    return createdBy;
	  }

	  /**
	   * Sets the value of the 'createdBy' field.
	   * maker of the transcation
	   * @param value the value to set.
	   */
	  public void setCreatedBy(String value) {
	    this.createdBy = value;
	  }

	  /**
	   * Gets the value of the 'firmCode' field.
	   * @return Firm code of the trade
	   */
	  public String getFirmCode() {
	    return firmCode;
	  }

	  /**
	   * Sets the value of the 'firmCode' field.
	   * Firm code of the trade
	   * @param value the value to set.
	   */
	  public void setFirmCode(String value) {
	    this.firmCode = value;
	  }


	  /**
	   * Gets the value of the 'portfolioCode' field.
	   * @return portfolio code
	   */
	  public String getPortfolioCode() {
	    return portfolioCode;
	  }

	  /**
	   * Sets the value of the 'portfolioCode' field.
	   * portfolio code
	   * @param value the value to set.
	   */
	  public void setPortfolioCode(String value) {
	    this.portfolioCode = value;
	  }

	  /**
	   * Gets the value of the 'filePath' field.
	   * @return FILE_PATH
	   */
	  public String getFilePath() {
	    return filePath;
	  }

	  /**
	   * Sets the value of the 'filePath' field.
	   * FILE_PATH
	   * @param value the value to set.
	   */
	  public void setFilePath(String value) {
	    this.filePath = value;
	  }

	  /**
	   * Gets the value of the 'assetTypeCode' field.
	   * @return ASSET_TYPE_CODE
	   */
	  public String getAssetTypeCode() {
	    return assetTypeCode;
	  }

	  /**
	   * Sets the value of the 'assetTypeCode' field.
	   * ASSET_TYPE_CODE
	   * @param value the value to set.
	   */
	  public void setAssetTypeCode(String value) {
	    this.assetTypeCode = value;
	  }

	  /**
	   * Gets the value of the 'fileType' field.
	   * @return FILE_TYPE
	   */
	  public String getFileType() {
	    return fileType;
	  }

	  /**
	   * Sets the value of the 'fileType' field.
	   * FILE_TYPE
	   * @param value the value to set.
	   */
	  public void setFileType(String value) {
	    this.fileType = value;
	  }
	  /**
	   * Gets the value of the 'severity' field.
	   * @return severity of the transaction
	   */
	  public String getSeverity() {
	    return severity;
	  }

	  /**
	   * Sets the value of the 'severity' field.
	   * severity of the transaction
	   * @param value the value to set.
	   */
	  public void setSeverity(String value) {
	    this.severity = value;
	  }
	  /**
	   * Gets the value of the 'severity' field.
	   * @return severity of the transaction
	   */
	  public int getAging() {
	    return aging;
	  }

	  /**
	   * Sets the value of the 'aging' field.
	   * aging of the transaction
	   * @param value the value to set.
	   */
	  public void setAging(int value) {
	    this.aging = value;
	  }
	  /**
	   * Gets the value of the 'status' field.
	   * @return status of the transaction
	   */
	  public String getStatus() {
	    return status;
	  }

	  /**
	   * Sets the value of the 'status' field.
	   * status of the transaction
	   * @param value the value to set.
	   */
	  public void setStatus(String value) {
	    this.status = value;
	  }

	  public void retrieveRuleGeneratedFields(String json) {
		  if (json == null || json.length() < 1) return ;
		  JSONObject jo = new JSONObject(json);
		  Object o = jo.get("severity");
		  if (o != null) severity = o.toString();
		  o = jo.get("status");
		  if (o != null) status = o.toString();
		  o = jo.get("aging");
		  if (o!=null) aging = Double.valueOf(o.toString()).intValue();
	  }
	  
	  public static String toMongoDBQueryStr(EventPojo e) {
		  StringBuffer buffer = new StringBuffer("");
		  buffer.append("{\"query\":\"mutation{createTPException(");
		  buffer = e.getCoreSystem()==null ? buffer.append("coreSystem:null,") : buffer.append("coreSystem:\\\"").append(e.getCoreSystem()).append("\\\","); 
		  buffer.append("createdDate:").append(e.getCreatedDate()).append(",");
		  buffer.append("updatedDate:").append(e.getUpdatedDate()).append(",");
		  buffer = e.getExecutingBroker()==null ? buffer.append("executingBroker:null,") : buffer.append("executingBroker:\\\"").append(e.getExecutingBroker()).append("\\\","); 
		  buffer = e.getErrorDescription()==null ? buffer.append("errorDescription:null,") : buffer.append("errorDescription:\\\"").append(e.getErrorDescription()).append("\\\","); 
		  buffer = e.getExceptionCategory()==null ? buffer.append("exceptionCategory:null,") : buffer.append("exceptionCategory:\\\"").append(e.getExceptionCategory()).append("\\\","); 
		  buffer = e.getErrorCategory()==null ? buffer.append("errorCategory:null,") : buffer.append("errorCategory:\\\"").append(e.getErrorCategory()).append("\\\","); 
		  buffer = e.getSource()==null ? buffer.append("source:null,") : buffer.append("source:\\\"").append(e.getSource()).append("\\\",");
		  buffer = e.getBlockExternalReferenceId()==null ? buffer.append("blockExternalReferenceId:null,") : buffer.append("blockExternalReferenceId:\\\"").append(e.getBlockExternalReferenceId()).append("\\\",");
		  buffer.append("transactionId:").append(e.getTransactionId()).append(",");
		  buffer = e.getFirmCode()==null ? buffer.append("firmCode:null,") : buffer.append("firmCode:\\\"").append(e.getFirmCode()).append("\\\",");
		  buffer = e.getAssetClass()==null ? buffer.append("assetClass:null,") : buffer.append("assetClass:\\\"").append(e.getAssetClass()).append("\\\",");
		  buffer = e.getAssetTypeCode()==null ? buffer.append("assetTypeCode:null,") : buffer.append("assetTypeCode:\\\"").append(e.getAssetTypeCode()).append("\\\",");
		  buffer = e.getPortfolioCode()==null ? buffer.append("portfolioCode:null,") : buffer.append("portfolioCode:\\\"").append(e.getPortfolioCode()).append("\\\",");
		  buffer = e.getAllocationId()==null ? buffer.append("allocationId:null,") : buffer.append("allocationId:\\\"").append(e.getAllocationId()).append("\\\",");
		  buffer.append("quantity:").append(e.getQuantity()).append(",");
		  buffer = e.getCustodianAccount()==null ? buffer.append("custodianAccount:null,") : buffer.append("custodianAccount:\\\"").append(e.getCustodianAccount()).append("\\\",");
		  buffer = e.getFilePath()==null ? buffer.append("filePath:null,") : buffer.append("filePath:\\\"").append(e.getFilePath()).append("\\\",");
		  buffer = e.getFileType()==null ? buffer.append("fileType:null,") : buffer.append("fileType:\\\"").append(e.getFileType()).append("\\\",");
		  buffer = e.getCreatedBy()==null ? buffer.append("createdBy:null,") : buffer.append("createdBy:\\\"").append(e.getCreatedBy()).append("\\\",");		  
		  buffer = e.getSeverity()==null ? buffer.append("severity:null,") : buffer.append("severity:\\\"").append(e.getSeverity()).append("\\\",");		  
		  buffer.append("aging:").append(e.getAging()).append(",");
		  buffer = e.getStatus()==null ? buffer.append("status:null,") : buffer.append("status:\\\"").append(e.getStatus()).append("\\\",");		  
		  buffer.append("batchId:").append(e.getBatchId()).append(")");
		  buffer.append("{_id}}\"}");
		  return buffer.toString();

	  }
}
