package com.citigroup.ewb.domain.components;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.config.ApplicationConfig;
import com.citigroup.ewb.config.KafkaProducerConfig;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;

@Component
public class C_Analysis<T, S> extends EventTransformer<KStream<String, Event>,KStream<String, Event>> {
	
	private static final Logger logger = LogManager.getLogger(C_Analysis.class);	
	
	@Autowired
	ApplicationConfig config;
	
	public AnalysisModel getAnalysisModel() {
		return (AnalysisModel)this.model;
	}

	public boolean isModelReady() {
		if (this.model != null && beginSource != null ) return true;
		return false;
	}
		
	C_Source beginSource = null;
	/**
	 * @startuml
	 * start
	 * :C_Source;
	 * :C_EventRicher;
	 * if(Filter is available)
	 * :C_Filter;
	 * endif
	 * :C_Aggregator;
	 * :C_Sink;
	 * stop
	 * @enduml
	 */
	/**
	 * @throws ProcessingException 
	 * 
	 */
	public void initialize() throws ProcessingException {
		
		AnalysisModel analysisModel = (AnalysisModel) this.model;
		MeasureModel[] measureModels = analysisModel.getMeasures();
		System.out.print("initialize " + measureModels.length + " models");
	
		C_Measure<KStream<String, Event>,KStream<String, Event>> premeasure = null;

		C_Measure<KStream<String, Event>,KStream<String, Event>> firstmeasure = null;
	
		C_Source<KStream<String, Event>,KStream<String, Event>> source = new C_Source();
		if (beginSource == null) beginSource = source;
		source.setModel(model);
//		measure.registerInput(source);
	    logger.debug("Building processing topology...");

	    C_EventEnricher<KStream<String, Event>,KStream<String, Event>> enricher = new C_EventEnricher();
		enricher.setModel(model);
		enricher.setFieldRule(config.getFieldRule());
		enricher.initialize();
		source.registerOutput(enricher);
		
		C_Post post = new C_Post();
		post.setModel(model);
		post.setQuerysvcurl(config.getQuerySvcUrl());
		post.setChangeventurl(config.getChangeEventSvcUrl());
		enricher.registerOutput(post);
		
		for (MeasureModel m : measureModels) {
			C_Measure<KStream<String, Event>,KStream<String, Event>> measure = new C_Measure<KStream<String, Event>,KStream<String, Event>>();
			measure.setModel(m);

			C_Aggregator<KStream<String, Event>,KStream<String, Event>> aggregator = new C_Aggregator();
			aggregator.setModel(m);
			post.registerOutput(measure);
			if (m.getFilter().getConditions() != null && m.getFilter().getConditions().length>=1) {
				C_Filter<KStream<String, Event>,KStream<String, Event>> filter = new C_Filter<KStream<String, Event>,KStream<String, Event>>();
				filter.setModel(m.getFilter());
				measure.registerOutput(filter);
				filter.registerOutput(aggregator);
			}
			else
				measure.registerOutput(aggregator);
			EventTransformer sink = new C_Sink<KStream<String, Event>,  KStream<String, Long>>();
			sink.setModel(m);
			aggregator.registerOutput(sink);
			C_WindowAggregator<KStream<String, Event>,KStream<String, Event>> w_aggregator = new C_WindowAggregator();
			w_aggregator.setModel(m);
			w_aggregator.setFrontendSvcUrl(config.getFrontendSvcUrl());
			aggregator.registerOutput((EventTransformer)w_aggregator);
		}
	}

	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		// TODO Auto-generated method stub
		this.beginSource.configureProcessingTopology(builder, events, keySerde, valueSerde);
	//	return events;
	}

	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
