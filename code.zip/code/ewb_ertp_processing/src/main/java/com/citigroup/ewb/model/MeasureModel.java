package com.citigroup.ewb.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author zh22901
 *
 */
public class MeasureModel extends Model {
	
	String aggregator;
	String field;
	FilterModel filter;
	String bucket_field;
	String[] bucket_criteria;
	String[] group_fields;
	long window;
	String type;
	String unit;
	
	public void setUnit(String unit) {
		this.unit = unit;
	}
	
	public String getUnit() {
		return this.unit;
	}
	
	public void setAggregator(String aggregator) {
		this.aggregator = aggregator;
	}
	
	public String getAggregator() {
		return this.aggregator;
	}
	
	public void setField(String field) {
		this.field = field;
	}
	
	public String getField() {
		return this.field;
	}
	
	public void setFilter(FilterModel filter) {
		this.filter = filter;
	}
	
	public FilterModel getFilter() {
		return this.filter;
	}
	
	public void setBucket_field(String bucket_field) {
		this.bucket_field = bucket_field;
	}
	
	public String getBucket_field() {
		return this.bucket_field;
	}
	
	public void setBucket_criteria(String[] bucket_criteria) {
		this.bucket_criteria = bucket_criteria;
	}
	
	public String[] getBucket_criteria() {
		return this.bucket_criteria;
	}
	
	public String[] getGroup_fields() {
		return this.group_fields;
	}
	
	public void setGroup_fields(String[] group_fields) {
		this.group_fields = group_fields;
	}
	
	public void setWindow(Long window) {
		this.window = window;
	}
	
	public Long getWindow() {
		return this.window;
	}	
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return this.type;
	}
	
	public String[] getKeys() {
		List<String> keys = new ArrayList<String>();
		for (String field : getGroup_fields()) {
			keys.add(field);
		}
		keys.add("BUCKET");
		String[] rtnstr = new String[keys.size()];
		for(int i=0; i<rtnstr.length;i++) {
			rtnstr[i] = keys.get(i);
		}
		return rtnstr;
	}

	public static MeasureModel generateSampleMeasure() {
		MeasureModel m = new MeasureModel();
			
		m.aggregator = "cnt";
		m.bucket_field = "$Event.QUANTITY";
		m.bucket_criteria = new String[3];
		m.bucket_criteria[0] = "100";
		m.bucket_criteria[1] = "2000";
		m.bucket_criteria[2] = "5000";
		m.field="$Event.id";
		m.filter=FilterModel.generateSampleFilter();
		m.group_fields= new String[2];
		m.group_fields[0] = "$event.firmCode";
		m.group_fields[1] = "$event.assetclass";
		m.window = 100;
		m.type = "TPE.assetclass.Statistic";
		m.unit = "hour";
		return m;
	}
}
