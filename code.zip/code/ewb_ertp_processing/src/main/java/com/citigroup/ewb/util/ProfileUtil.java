package com.citigroup.ewb.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONObject;

import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;

public class ProfileUtil {
	
	public final static String DATA_TYPE_STRING = "STRING";
	public final static String DATA_TYPE_NUMBER = "NUMBER";	
	public final static String DATA_TYPE_DATE = "DATE";	
	
	public final static String PROFILEFIELD = new String("profile");
	public final static String PROFILETIMEFIELD = new String("profileTime");
	public final static String PROFILEKEYFIELD = new String("profileKey");
	
	
	public static Object getValue(String inputValue, String type) {
		Object rtnobj = null;
		switch (type) {
			case DATA_TYPE_NUMBER :
				rtnobj = Double.valueOf(inputValue);
				break;
			case DATA_TYPE_DATE :
				rtnobj = new Date(Long.valueOf(inputValue));
				break;
			case DATA_TYPE_STRING :
				rtnobj = inputValue;
				break;
			default :
				rtnobj = inputValue;
				break;
		}
		return rtnobj;
	}
	
	public static String getProfileKeyWithoutTime (String profilekey) {
		String[] keys = profilekey.split("#");
		StringBuffer newkey = new StringBuffer("");
		int l = 0;
    	for (String k: keys) {
    		newkey.append(k).append("#");
    		l++;
    		if (l==keys.length -1) break;
    	}
    	return newkey.toString();
	}
	
	public static String getTimePart (String profilekey) {
		String[] keys = profilekey.split("#");
    	return keys[keys.length-1];
	}
	
    public static Map parseKeyValue(MeasureModel model, String key, String value) {
    	String[] keys = model.getKeys();
  	  Map newrow = new LinkedHashMap();
  	  if (!key.startsWith("total")) {
  	  	  newrow.put("TABLENAME", model.getType());
  		  System.out.println("count for " + key + ": " +value);
  		  String[] values = key.split("#");
  		  int keyindex = 0;
  		  String timeColumn = null;
  		  for (String v : values) {
  	  		  System.out.println("verify " + v);
  			  if (v.equalsIgnoreCase("total")) continue;

  			  if (timeColumn != null) {
  				  Date timevalue = new Date(Long.valueOf(v));
  				  SimpleDateFormat f = new SimpleDateFormat();  
  				  newrow.put(timeColumn, f.format(timevalue));
  				  timeColumn = null;
  				  break;
  			  }
  			  if (keys[keyindex].equalsIgnoreCase("BUCKET")) {
  				  if (v.length()<1) newrow.put(keys[keyindex], new Integer(0));
  				  else newrow.put(keys[keyindex], Integer.valueOf(v.trim()));
  				  keyindex++;
  	  	  		  System.out.println("set time " + v);
  				  timeColumn = new String("TIME");
  				  continue;
  			  }
		    		  
  			  newrow.put(AnalysisModel.parseField(keys[keyindex]), v);
		   		  keyindex++;
	    	  }
	    	  newrow.put("VALUE", value);
  	  }
  	  return newrow;
    }
    
    public static Map parseTotalKeyValue(MeasureModel model, String key, String value) {
    	String[] keys = model.getKeys();
  	  Map newrow = new LinkedHashMap();

  	  if (key.startsWith("total")) {
  	  	  newrow.put("TABLENAME", model.getType());
  		  System.out.println("count for " + key + ": " +value);
  		  String[] values = key.split("#");
	    	  
  		  int keyindex = 0;
  		  for (String v : values) {
  			  System.out.print("current value: "+v+"\n");
  			  if (v.equalsIgnoreCase("total")) continue;

  			  if (keys[keyindex].equalsIgnoreCase("BUCKET")) {
  				  if (v.length()<1) newrow.put(keys[keyindex], new Integer(0));
  				  else newrow.put(keys[keyindex], Integer.valueOf(v.trim()));
  				  break;
  			  }
	    		  
  			  newrow.put(AnalysisModel.parseField(keys[keyindex]), v);
  			  keyindex++;
  		  }
  		  newrow.put("VALUE", value);
  	  }    	
  	  return newrow;
    }

    public static String createNewProfile(String key, String value, String type) {
    	String jsonString = new JSONObject()
                .put(key, value)
                .toString();
    	return jsonString;
    }
    
    public static String updateProfile(String profile, String key, String value, String type) {
    	JSONObject json = new JSONObject(profile);
    	json.put(key, value);
    //    json.append(key, value);      
    	return json.toString();
    }
    
    public static String getProfileValue(String profile, String key) {
    	JSONObject json = new JSONObject(profile);
    	Object v = json.get(key);
    	String value = json.get(key).toString();
    	return value;
    }
    
    public static void main(String[] args) {
    	String profile = createNewProfile("aging", "1496.94436", "NUMBER");
    	profile = updateProfile(profile, "severity", "Medium", "STRING");
    	profile = updateProfile(profile, "status", "new", "STRING");   	
  //  	String profile = "{\"severity\":[\"Medium\"],\"aging\":\"1496.94435\",\"status\":[\"new\"]}";
    	String value = getProfileValue(profile, "severity");
    }
  }
