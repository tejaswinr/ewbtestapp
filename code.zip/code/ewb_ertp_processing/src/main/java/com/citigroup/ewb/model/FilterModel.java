package com.citigroup.ewb.model;

/**
 * 	 The class is to hold a condition defined with similar structure to below
 *    "filter": {
           "relation": "all",
           "conditions": [{
               "field": "$event.category",
               "function": "equals",
               "paramters": [
                   "BUSINESS_VALIDATION"
               ]
           }]
      }
 * @author zh22901
 *
 */
public class FilterModel extends Model {
	
	String relation;
	ConditionModel[] conditions;
	
	public void setRelation(String relation) {
		this.relation = relation;
	}
	
	public String getRelation() {
		return this.relation;
	}
	
	public void setConditions(ConditionModel[] conditions) {
		this.conditions = conditions;
	}
	
	public ConditionModel[] getConditions() {
		return this.conditions;
	}
	
	public static FilterModel generateSampleFilter() {
		FilterModel f = new FilterModel();
		f.relation = "all";
		ConditionModel[] conditions = new ConditionModel[1];
		conditions[0] = ConditionModel.generateSampleCondition();
		f.conditions=conditions;
		return f;
	}
	
}
