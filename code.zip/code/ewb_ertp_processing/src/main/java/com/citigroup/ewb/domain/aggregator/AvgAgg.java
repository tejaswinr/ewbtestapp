package com.citigroup.ewb.domain.aggregator;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.kstream.Aggregator;
import org.apache.kafka.streams.kstream.Initializer;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.LongSerde;
import com.citigroup.ewb.common.util.StringSerde;
import com.citigroup.ewb.util.ProfileUtil;

public class AvgAgg extends AbsAgg<Long> {

	@Override
	public KTable CalculateTopology(KStream<String, Event> events, String type, String field) {

		KGroupedStream<String, Event> groupedData = events.groupBy((key, value) -> value.get(ProfileUtil.PROFILEKEYFIELD).toString()); 
		
		KTable<String, Long> cntTable = groupedData.count(); 
		
/*		Serde doubleSerde = null;
		KTable cntTable = groupedData.aggregate(new Initializer<Double>() {
	        public Double apply() {
	            return 0.0;
	        }
	    }, new Aggregator<String, Event, Double>() {

	        @Override
	        public Double apply(String aggKey,  Event value, Double aggregate) {
	        	System.out.print("aggkey : " + aggKey + "\n");
	        	System.out.print("cnt : " + String.valueOf(1.0+aggregate) + "\n");
	            return 1.0 + aggregate;
	        }
	    }, doubleSerde, type+".cnt.store");*/
	    //System.out.print(cntTable.toString()+"\n");
	    return cntTable;
	}

	@Override
	public Serde getKeySerde() {
		// TODO Auto-generated method stub
		return new StringSerde();
	}

	@Override
	public Serde getValueSerde() {
		// TODO Auto-generated method stub
		return new LongSerde();
	}

	@Override
	public Long calculate(Long t1, Long t2) {
		if (t1 == null) t1 = 0L;
		if (t2 == null) t2 = 0L;		
		// TODO Auto-generated method stub
		return t1 + t2;
	}

}
