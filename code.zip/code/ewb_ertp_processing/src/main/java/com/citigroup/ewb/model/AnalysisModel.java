package com.citigroup.ewb.model;

import java.util.List;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

public class AnalysisModel extends Model {
	
	Long fromtime;
	Long endtime;
	String name;
	EnrichmentModel[] enrichments;
	MeasureModel[] measures;
	
	public void setFromtime(long fromtime) {
		this.fromtime = fromtime;
	}
	
	public Long getFromtime() {
		return this.fromtime;
	}

	public void setEndtime(long endtime) {
		this.endtime = endtime;
	}
	
	public Long getEndtime() {
		return this.endtime;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setMeasures(MeasureModel[] measures) {
		this.measures = measures;
	}

	public MeasureModel[] getMeasures() {
		return this.measures;
	}

	public void setEnrichments(EnrichmentModel[] enrichments) {
		this.enrichments = enrichments;
	}

	public EnrichmentModel[] getEnrichments() {
		return this.enrichments;
	}
	
	public MeasureModel getMeasureModel(String tablename) {
		MeasureModel rtnModel = null;
		for (MeasureModel m: this.measures) {
			if (m.getType().equals(tablename)) {
				rtnModel = m;
				break;
			}
		}	
		return rtnModel;
	}
	
	public String[] getMeasureModelKeys(String name) {
		List<String> keys = new ArrayList<String>();
		for (MeasureModel m: this.measures) {
			if (m.getType().equals(name)) {
				for (String field : m.getGroup_fields()) {
					keys.add(field);
				}
	//			if (m.bucket_field!=null && m.bucket_field.trim().length()>0) {
					keys.add("BUCKET");
	//			}
			}

		}
		String[] rtnstr = new String[keys.size()];
		for(int i=0; i<rtnstr.length;i++) {
			rtnstr[i] = keys.get(i);
		}
		return rtnstr;
	}
	
	public static String parseField(String entityfield) {
		System.out.print("parse field: " + entityfield + "\n");
		if (!entityfield.contains(".")) 
			return entityfield;
		String[] names = entityfield.split(Pattern.quote("."));
		System.out.print("parsed field: " + names[0] + "\n");		
		return names[1];
	}
	
	public static AnalysisModel generateSampleModel() {
		AnalysisModel model = new AnalysisModel();
		
		EnrichmentModel[] ems = new EnrichmentModel[2];
		ems[0] = new EnrichmentModel();
		ems[0].setField("severity");
		ems[0].setExpression("rules:r_field_severity($Event)");
		ems[0].setType("STRING");
		ems[1] = new EnrichmentModel();
		ems[1].setField("status");
		ems[1].setExpression("new");
		ems[1].setType("STRING");
		model.setEnrichments(ems);;
		
		String dateString = "Nov 1, 2017 8:14 PM";

		// Get the default MEDIUM/SHORT DateFormat
		DateFormat format = 
	    DateFormat.getDateTimeInstance(
	    DateFormat.MEDIUM, DateFormat.SHORT);

	    // Parse the date
	    try {
	        Date date = format.parse(dateString);
	        model.fromtime = date.getTime();
	    }
	    catch(ParseException pe) {
	        System.out.println("ERROR: could not parse date in string \"" +
	        dateString + "\"");
	    }		
		
 		dateString = "Dec 1, 2017 8:14 PM";

		// Get the default MEDIUM/SHORT DateFormat
		// Parse the date
		try {
		    Date date = format.parse(dateString);
		    model.endtime = date.getTime();
		}
		catch(ParseException pe) {
		    System.out.println("ERROR: could not parse date in string \"" +
		    dateString + "\"");
	    }		
		
		model.name= "Trade Processing Exception";
		model.measures = new MeasureModel[1];
		model.measures[0] = MeasureModel.generateSampleMeasure();
		
		return model;
	}
	
}
