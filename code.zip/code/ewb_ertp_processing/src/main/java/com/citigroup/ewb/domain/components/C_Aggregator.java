package com.citigroup.ewb.domain.components;

import java.util.List;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.domain.aggregator.AbsAgg;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;

public class C_Aggregator<T, S> extends EventTransformer<KStream<String, Event>,S>
{
	Serde stringSerde;// = Serdes.String();
    Serde eventSerde;// = Serdes.serdeFrom(Event.class);
    boolean allUnit = false;
    
    public void setAllUnit(boolean b) {this.allUnit = b;}
    
	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		   
	MeasureModel m = (MeasureModel)this.model;
	    String field = m.getField();
	    String aggname = m.getAggregator();
	    AbsAgg agg = AbsAgg.getAggInstance(aggname);
	    
	    KTable aggTable = agg.CalculateTopology(events, m.getType(), AnalysisModel.parseField(field));
	    aggTable.print();
	    
	   // KTable<String, Event> sumTable = builder.table(stringSerde, EventSerde, "sum", "sumStoreName");
	  //  sumTable.toStream().process(SmokeTestUtil.printProcessorSupplier("sum"));
	    
	    keySerde = agg.getKeySerde();
	    valueSerde = agg.getValueSerde();
	    KStream aggstream = aggTable.toStream();
		configureDownstreamTopology(builder, (S)aggstream, keySerde, valueSerde);	 	
	}

	@Override
	public S transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
