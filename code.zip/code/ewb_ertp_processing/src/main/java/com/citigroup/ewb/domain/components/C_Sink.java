package com.citigroup.ewb.domain.components;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;

import org.apache.kafka.streams.kstream.KStream;

import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.StoreBuilder;
import org.apache.kafka.streams.state.Stores;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.ConditionModel;
import com.citigroup.ewb.model.FilterModel;
import com.citigroup.ewb.model.MeasureModel;

public class C_Sink<T,S> extends EventTransformer<KStream<String, S>,KStream<String, S>>{

	private static final int AND = 1;
	private static final int OR = 0;
	

	@Override
	public KStream<String, S> transform(KStream<String, S> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, S> events, Serde keySerde,
			Serde valueSerde) throws ProcessingException {
		// TODO Auto-generated method stub
		MeasureModel mm = (MeasureModel)this.model;

		StoreBuilder<KeyValueStore<String, Long>> countStoreSupplier = Stores.keyValueStoreBuilder(
				  Stores.persistentKeyValueStore( mm.getType()+".aggregator.store"),
				  keySerde,
				valueSerde);//.withLoggingDisabled();
		builder.addStateStore(countStoreSupplier);
		
	//	builder.addStateStore(Stores.create("store").withIntegerKeys().withByteArrayValues().persistent().build());
//		events.to(mm.getType());
		events.to(keySerde, valueSerde, mm.getType()+".aggregator.store");
	}
}
