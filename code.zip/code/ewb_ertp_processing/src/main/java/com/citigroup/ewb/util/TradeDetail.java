package com.citigroup.ewb.util;

public class TradeDetail {
	  /** Transcation ID for the trade */
	  public long transactionId;
	  /** Firm code of the trade */
	  public String firmCode;
	  /** Asset class of the security */
	  public String assetClass;
	  /** ASSET_TYPE_CODE */
	  public String assetTypeCode;
	  /** portfolio code */
	  public String portfolioCode;
	  /** ALLOCATION_ID */
	  public String allocationId;
	  /** Quantity of the trade */
	  public int quantity;
	  /** Custodian account */
	  public String custodianAccount;
	  /** FILE_PATH */
	  public String filePath;
	  /** FILE_TYPE */
	  public String fileType;
	  /** maker of the transcation */
	  public String createdBy;
	  
	  public TradeDetail() {}
	  /**
	   * Gets the value of the 'transactionId' field.
	   * @return Transcation ID for the trade
	   */
	  public java.lang.Long getTransactionId() {
	    return transactionId;
	  }

	  /**
	   * Sets the value of the 'transactionId' field.
	   * Transcation ID for the trade
	   * @param value the value to set.
	   */
	  public void setTransactionId(java.lang.Long value) {
	    this.transactionId = value;
	  }

	  /**
	   * Gets the value of the 'quantity' field.
	   * @return Quantity of the trade
	   */
	  public java.lang.Integer getQuantity() {
	    return quantity;
	  }

	  /**
	   * Sets the value of the 'quantity' field.
	   * Quantity of the trade
	   * @param value the value to set.
	   */
	  public void setQuantity(java.lang.Integer value) {
	    this.quantity = value;
	  }

	  /**
	   * Gets the value of the 'custodianAccount' field.
	   * @return Custodian account
	   */
	  public String getCustodianAccount() {
	    return custodianAccount;
	  }

	  /**
	   * Sets the value of the 'custodianAccount' field.
	   * Custodian account
	   * @param value the value to set.
	   */
	  public void setCustodianAccount(String value) {
	    this.custodianAccount = value;
	  }


	  /**
	   * Gets the value of the 'assetClass' field.
	   * @return Asset class of the security
	   */
	  public String getAssetClass() {
	    return assetClass;
	  }

	  /**
	   * Sets the value of the 'assetClass' field.
	   * Asset class of the security
	   * @param value the value to set.
	   */
	  public void setAssetClass(String value) {
	    this.assetClass = value;
	  }

	  /**
	   * Gets the value of the 'allocationId' field.
	   * @return ALLOCATION_ID
	   */
	  public String getAllocationId() {
	    return allocationId;
	  }

	  /**
	   * Sets the value of the 'allocationId' field.
	   * ALLOCATION_ID
	   * @param value the value to set.
	   */
	  public void setAllocationId(String value) {
	    this.allocationId = value;
	  }

	  /**
	   * Gets the value of the 'createdBy' field.
	   * @return maker of the transcation
	   */
	  public String getCreatedBy() {
	    return createdBy;
	  }

	  /**
	   * Sets the value of the 'createdBy' field.
	   * maker of the transcation
	   * @param value the value to set.
	   */
	  public void setCreatedBy(String value) {
	    this.createdBy = value;
	  }

	  /**
	   * Gets the value of the 'firmCode' field.
	   * @return Firm code of the trade
	   */
	  public String getFirmCode() {
	    return firmCode;
	  }

	  /**
	   * Sets the value of the 'firmCode' field.
	   * Firm code of the trade
	   * @param value the value to set.
	   */
	  public void setFirmCode(String value) {
	    this.firmCode = value;
	  }


	  /**
	   * Gets the value of the 'portfolioCode' field.
	   * @return portfolio code
	   */
	  public String getPortfolioCode() {
	    return portfolioCode;
	  }

	  /**
	   * Sets the value of the 'portfolioCode' field.
	   * portfolio code
	   * @param value the value to set.
	   */
	  public void setPortfolioCode(String value) {
	    this.portfolioCode = value;
	  }

	  /**
	   * Gets the value of the 'filePath' field.
	   * @return FILE_PATH
	   */
	  public String getFilePath() {
	    return filePath;
	  }

	  /**
	   * Sets the value of the 'filePath' field.
	   * FILE_PATH
	   * @param value the value to set.
	   */
	  public void setFilePath(String value) {
	    this.filePath = value;
	  }

	  /**
	   * Gets the value of the 'assetTypeCode' field.
	   * @return ASSET_TYPE_CODE
	   */
	  public String getAssetTypeCode() {
	    return assetTypeCode;
	  }

	  /**
	   * Sets the value of the 'assetTypeCode' field.
	   * ASSET_TYPE_CODE
	   * @param value the value to set.
	   */
	  public void setAssetTypeCode(String value) {
	    this.assetTypeCode = value;
	  }

	  /**
	   * Gets the value of the 'fileType' field.
	   * @return FILE_TYPE
	   */
	  public String getFileType() {
	    return fileType;
	  }

	  /**
	   * Sets the value of the 'fileType' field.
	   * FILE_TYPE
	   * @param value the value to set.
	   */
	  public void setFileType(String value) {
	    this.fileType = value;
	  }

}
