package com.citigroup.ewb.controllers;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citigroup.ewb.domain.components.C_Analysis;
import com.citigroup.ewb.domain.AvroEventProducer;
import com.citigroup.ewb.domain.ProcessService;
import com.citigroup.ewb.domain.ProcessStream;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.AnalysisModel;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventAvroConverter;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.common.util.EventTransfer;

/**
 * to query kafka state, check pages as below
 * https://cwiki.apache.org/confluence/display/KAFKA/KIP-67%3A+Queryable+state+for+Kafka+Streams
 * @author Zhi Huang
 *
 */

@Configuration
@EnableAutoConfiguration
@EnableConfigurationProperties
@RestController
public class ProcessingController {
	
	private static final Logger logger = LogManager.getLogger(ProcessingController.class);
	
    @Autowired
	AvroEventProducer producer;
    
	@Autowired 
	private ProcessService processService; 
	
	@Autowired
	private ProcessStream stream;
	
	@Autowired
	C_Analysis analysisEngine;	
	
	@Value("${kafka.incoming.topic:trading}")
	private String kafkaRouterIncomingTopic;
	
    @RequestMapping(value = "/ewb/getEventSample", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) 
    public @ResponseBody Map  getEventJasonSample() {
    	Event e = EventGenerator.getNext();
    	
    	return EventAvroConverter.toMap(e);
    }
    
    @RequestMapping(value = "/ewb/getAggregators", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) 
    public @ResponseBody Map[]  getAggregators(@RequestParam("tablename") String name) {
    	return this.stream.getTotalKeyValuePairs(name);
    }
    
    @RequestMapping(value = "/ewb/getAggregatorDetails", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) 
    public @ResponseBody Map[]  getAllAggregators(@RequestParam("tablename") String name) {
    	Map[] m = this.stream.getAllKeyValuePairs(name);
    	return m;
    }
    
    @RequestMapping(value = "/ewb/getModelSample", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) 
    public @ResponseBody AnalysisModel  getModelSample() {
    	
    	return AnalysisModel.generateSampleModel();
    }
    
    @RequestMapping(value = "/ewb/refreshModel", method=RequestMethod.POST) 
    public ResponseEntity<Map<String, String>> refreshModel(@RequestBody AnalysisModel model) throws ProcessingException {
    	analysisEngine.cleanUp();
    	
    	analysisEngine.setModel(model);
    	analysisEngine.initialize();
    	Map<String, String> response = new HashMap<>(); 
        response.put("message", "model is refreshed");
        
        return new ResponseEntity<>(response, HttpStatus.OK);     	
    }    
    
    @RequestMapping(value = "/getResults", method=RequestMethod.POST) 
    public ResponseEntity<Map<String, String>>  getResults(@RequestBody String results) {
    	System.out.print("receive result: ");
		System.out.print(results.toString());
		System.out.print("\n");		
/*
    	JSONObject json = new JSONObject();
		Iterator keyindex = results.keySet().iterator();
		while (keyindex.hasNext()) {
			Object k = keyindex.next();
			String v = results.get(k).toString();
			json.put((String)k, v);
		}
    	
	    httpSession.setAttribute("data", json.toString());
		
        return "viewResults";*/
    	Map<String, String> response = new HashMap<>(); 
        response.put("message", "results retrieved, thank you!");
        
        return new ResponseEntity<>(response, HttpStatus.OK);   
		
    }    
/*    @RequestMapping(value = "/ewb/eventProcess", method=RequestMethod.POST) 
    public @ResponseBody RecordMetadata eventProcess(@RequestBody com.citigroup.ewb.common.util.EventTransfer et) {
    	RecordMetadata rm = null;
    	try {
    		Event event = et.restoreEvent();
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    	}
    	return rm;
    }*/
    
    @RequestMapping(value = "/ewb/eventProcess", method=RequestMethod.POST) 
    public @ResponseBody RecordMetadata eventProcess(@RequestBody Map em) {
    	Event event = EventAvroConverter.mapToEvent(em);
    	RecordMetadata rm = null;
    	try {
    		System.out.print(event.toString());
    		rm = this.producer.produce(event, kafkaRouterIncomingTopic);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    	}
    	return rm;
    }   
    
    @RequestMapping(value = "/ewb/startProcessing", method = RequestMethod.GET) 
    public ResponseEntity<Map<String, String>> startProcessingSvc() { 
    	processService.process(); 
    	Map<String, String> response = new HashMap<>(); 
        response.put("message", "Request is under process"); 
        return new ResponseEntity<>(response, HttpStatus.OK); 
    } 

    @RequestMapping(value = "/ewb/stopProcessing", method = RequestMethod.GET) 
    public ResponseEntity<Map<String, String>> stopProcessingSvc() { 
    	processService.stop(); 
    	Map<String, String> response = new HashMap<>(); 
        response.put("message", "processing is stopped"); 
        return new ResponseEntity<>(response, HttpStatus.OK); 
    } 

}
