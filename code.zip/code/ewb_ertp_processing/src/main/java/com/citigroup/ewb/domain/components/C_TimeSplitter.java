package com.citigroup.ewb.domain.components;

import java.util.Date;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Predicate;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.ConditionModel;
import com.citigroup.ewb.model.FilterModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.TimeUtil;

public class C_TimeSplitter<T,S>  extends EventTransformer<KStream<String, Event>,KStream<String, Event>> {

	public static final String timefield = "createdDate	";
	public static final String profiletimefield = "profileTime";
	
	private static Predicate<String, Event>[] generateTimeSpliterFilter(String unit, Long window, KStream<String, Event> events ) {

		Predicate<String, Event>[] ps = new Predicate[window.intValue()];
		int i=0;
		for (Predicate<String, Event> p : ps) {
			final int j = i;
			p = new Predicate<String, Event>() {
				@Override
                public boolean test(String k, Event v) {
					return ((long)(v.get(timefield)) - (long)(v.get(profiletimefield)) >= j) && ((long)(v.get(timefield)) - (long)(v.get(profiletimefield))<j+1);
				}
			};
			i++; 
		}
		return ps;
	}
	
	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {

		MeasureModel m = (MeasureModel)this.model;

		String unit = m.getUnit();
		Long window = m.getWindow();
		
	    Predicate<String, Event>[] ps = this.generateTimeSpliterFilter(unit, window, events);

		KStream<String, Event>[] branches = new KStream[window.intValue()];
		
		int i=0;
		for (Predicate<String, Event> p : ps) {
			branches[i] = events.filter(p);
			EventTransformer next = this.getOutput().get(i);
			next.configureProcessingTopology(builder , branches[i], keySerde, valueSerde);
			i++;
		}
//		return events;
	}

	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
