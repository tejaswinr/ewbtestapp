package com.citigroup.ewb.domain.components;

import java.util.Iterator;
import java.util.Map;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.EventPojo;
import com.citigroup.ewb.util.ProfileUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class C_Post<T, S> extends EventTransformer<KStream<String, Event>,KStream<String, Event>> {

	String querysvcurl;
	String changeeventurl;
	public void setQuerysvcurl(String url) {
		  this.querysvcurl = url;
	  }
	public void setChangeventurl(String url) {
		  this.changeeventurl = url;
	  }
	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde,
			Serde valueSerde) throws ProcessingException {
		// TODO Auto-generated method stub
//		String changeeventpublisherurl = "http://localhost:8080/api/v1/wallets/balance";

		events.foreach(new ForeachAction<String, Event>() {
		
	        public void apply(String key, Event value) {
			
				System.out.print( key + ": " + value.toString());
				AnalysisModel m = (AnalysisModel)model;
				
				EventPojo epojo = new EventPojo();
				epojo.importEvent(value);
				JSONObject jsonObj = new JSONObject(epojo);
//				String json = jsonObj.toString();
				ObjectMapper mapper = new ObjectMapper();
				String json;
				try {
					json = mapper.writeValueAsString(epojo);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return;
				}
				
				String finalstr = EventPojo.toMongoDBQueryStr(epojo);
				System.out.print("mongoDB : \n" + finalstr + "\n");

				postTo(querysvcurl, finalstr);
				
				postTo(changeeventurl, json.toString());	
				
				System.out.print("QuerySVC : \n" + json.toString() + "\n");
	        }
		});
		configureDownstreamTopology(builder, events, keySerde, valueSerde);		
    }

	public static void postTo(String url, String value) {
		System.out.print("post to : " + url);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");

		HttpEntity <String> httpEntity = new HttpEntity <String> (value, httpHeaders);
		
		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject(url, httpEntity, String.class);

		System.out.print("response: " + response);
	}
	
	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
