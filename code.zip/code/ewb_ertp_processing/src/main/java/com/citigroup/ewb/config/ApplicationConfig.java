package com.citigroup.ewb.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:application.properties")
public class ApplicationConfig {

	@Autowired
	private Environment evn;
	
	@Value("${processing.topic:trading}")
	private String kafkaIncomingTopic;
	
	@Value("${base.dir}")
	private String basedir;

	@Value("${processing.rule.field:com.citigroup.ewb.domain.rules.RandomFieldRule}")
	private String fieldRule;

	@Value("${change.event.publisher.svc.url:http://localhost:8080/ewb/analysisData}")
	public String changeeventpublisherurl;
	
	@Value("${query.svc.url:http://localhost:8080/ewb/getResults}")
	public String querysvcurl;	
	
	@Value("${frontend.svc.url:http://localhost:8080/ewb/getResults}")
	public String frontendsvcurl;		

	public String getBasedir() {
		return this.basedir;
	}
	
	public String getChangeEventSvcUrl() {
		return this.changeeventpublisherurl;
	}
	
	public String getFrontendSvcUrl() {
		return this.frontendsvcurl;
	}
	
	public String getQuerySvcUrl() {
		return this.querysvcurl;
	}
	
	public String getFieldRule() {
		return this.fieldRule;
	}
	
}
