package com.citigroup.ewb.domain.components;

import org.apache.avro.Schema.Type;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Predicate;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.MeasureModel;

public class C_Bucket<T, S> extends EventTransformer<KStream<String, Event>,KStream<String, Event>> {
	
	private static final int NUMBERFUNCTION_GREATER = 1;
	private static final int NUMBERFUNCTION_LESS = -1;
	private static final int NUMBERFUNCTION_BETWEEN = 0;
	
	public static Predicate<String, Event> generatePredicate(String field, String[] parameters, int function) throws ProcessingException {
		Predicate<String, Event> p = null;
		Type type = Event.getClassSchema().getField(field).schema().getType();
		if (type == Type.STRING) {
			throw new ProcessingException("Wrong field type for bucket");
		}
		else if (type == Type.INT || type == Type.DOUBLE || type == Type.FLOAT || type == Type.LONG) {
			if (function == NUMBERFUNCTION_BETWEEN && parameters.length != 2 ) throw new ProcessingException("Length of parameter for middle bucket is wrong");
			if ((function == NUMBERFUNCTION_GREATER || function ==  NUMBERFUNCTION_LESS) && parameters.length != 1 ) throw new ProcessingException("Length of parameter for first or last bucket is wrong");
			switch(function) {
				case NUMBERFUNCTION_BETWEEN :
					p = (k, v) -> Double.valueOf(v.get(field).toString()) < Double.valueOf(parameters[0]) && Double.valueOf(v.get(field).toString()) >= Double.valueOf(parameters[1]);  
					break;
				case NUMBERFUNCTION_GREATER :
					p = (k, v) -> Double.valueOf(v.get(field).toString()) >= Double.valueOf(parameters[0]);  
					break;
				case NUMBERFUNCTION_LESS :
					p = (k, v) -> Double.valueOf(v.get(field).toString()) < Double.valueOf(parameters[0]);  
					break;
				default :
					break;
			}
		}		
		return p;
	}
	
	private static Predicate<String, Event>[] generateBucketFilter(String field, String[] bucket_criteria, KStream<String, Event> events ) throws ProcessingException {
	
		Predicate<String, Event>[] ps = new Predicate[bucket_criteria.length+1];
		int i=0;
		for (Predicate<String, Event> p : ps) {
			if (i==0) {
				String[] parameters = new String[1];
				parameters[0]=bucket_criteria[0];
				p = generatePredicate(field, parameters, NUMBERFUNCTION_LESS);
			}
			if (i==bucket_criteria.length) {
				String[] parameters = new String[1];
				parameters[0]=bucket_criteria[bucket_criteria.length-1];
				p = generatePredicate(field, parameters, NUMBERFUNCTION_GREATER);
			}
			else {
				String[] parameters = new String[2];
				parameters[0]=bucket_criteria[i];
				parameters[0]=bucket_criteria[i+1];
				p = generatePredicate(field, parameters, NUMBERFUNCTION_BETWEEN);
				
			}
		}
		
		return ps;
		
	}
	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		MeasureModel mm = (MeasureModel)this.model;
		String field = mm.getBucket_field();
		String[] bucket_criteria = mm.getBucket_criteria();
	    Predicate<String, Event>[] ps = this.generateBucketFilter(field, bucket_criteria, events);

		KStream<String, Event>[] branches = new KStream[bucket_criteria.length+1];
		int i=0;

		for (Predicate<String, Event> p : ps) {
			branches[i] = events.filter(p);
			EventTransformer next = this.getOutput().get(i);
			next.configureProcessingTopology(builder, branches[i], keySerde, valueSerde);
			i++;
		}

		
	}

}
