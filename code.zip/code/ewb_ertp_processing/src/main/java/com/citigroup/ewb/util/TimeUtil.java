package com.citigroup.ewb.util;

import java.util.Date;

public class TimeUtil {
	
	public static final String MINUTE = "second"; 
	public static final String SECOND = "minute";
	public static final String HOUR = "hour";
	public static final String DAY = "day";
	public static final String WEEK = "week";	
	public static final String MONTH = "month";
	public static final String QUATER = "quater";
	public static final String YEAR = "year";
	
	public static long calculateRightTimeUnitPoint(String unit, long startingtime) {
		long previousTimePoint = startingtime;
		switch (unit) {
			case SECOND :
				previousTimePoint = previousTimePoint - 1*1000;
				break;
			case MINUTE :
				previousTimePoint = previousTimePoint - 1*60*1000;
				break;
			case HOUR :
				previousTimePoint = previousTimePoint - 1*60*60*1000;
				break;
			case DAY :
				previousTimePoint = previousTimePoint - 1*24*60*60*1000;
				break;
			case WEEK :
				previousTimePoint = previousTimePoint - 1*7*60*60*1000;
				break;
			case MONTH :
				previousTimePoint = previousTimePoint - 1*30*60*60*1000; // 1 month (TBD :exact days)
				break;
			case YEAR :
				previousTimePoint = previousTimePoint - 1*365*60*60*1000;
				break;
			default :
				break;
		}
		return previousTimePoint;
	}
	
	public static long calculateWindowRange(String unit, long window) {
		long windowrange = -1;
		switch (unit) {
		case SECOND :
			windowrange =  (long) (window * 1000);
			break;
		case MINUTE :
			windowrange =  (long) (window * 60 * 1000);
			break;
		case HOUR :
			windowrange =  (long) (window * 60 * 60 * 1000);
			break;
		case DAY :
			windowrange =  (long) (window * 60 * 60 * 24 * 1000);
			break;
		case WEEK :
			windowrange =  (long) (window * 60 * 60 * 24 * 1000 * 7);
			break;
		case MONTH :
			// 1 month (TBD :exact days)
			windowrange =  (long) (window * 60 * 60 * 24 * 1000 * 30);
			break;
		case YEAR :
			// 1 month (TBD :exact days)
			windowrange =  (long) (window * 60 * 60 * 24 * 1000 * 365);
			break;
		default :
			break;
		}
		return windowrange;

	}
	
	public static long calculateStartingTime(String unit, long currentDateMS) {
		long currentTimePoint = -1;
		switch (unit) {
			case SECOND :
				currentTimePoint =  (((long) (currentDateMS / 1000)) * 1000);
				break;
			case MINUTE :
				currentTimePoint =  (((long) (currentDateMS / (1000 * 60))) * 60 * 1000);
				break;
			case HOUR :
				currentTimePoint =  (((long) (currentDateMS / (1000 * 60 * 60))) * 60 * 60 * 1000);
				break;
			case DAY :
				currentTimePoint =  (((long) (currentDateMS / (1000 * 60 * 60 * 24))) * 60 * 60 * 24 * 1000);
				break;
			case WEEK :
				currentTimePoint =  (((long) (currentDateMS / (1000 * 60 * 60 * 24 * 7))) * 60 * 60 * 24 * 1000 * 7);
				break;
			case MONTH :
				// 1 month (TBD :exact days)
				currentTimePoint =  (((long) (currentDateMS / (1000 * 60 * 60 * 24 * 30))) * 60 * 60 * 24 * 1000 * 30);
				break;
			case YEAR :
				// 1 month (TBD :exact days)
				currentTimePoint =  (((long) (currentDateMS / (1000 * 60 * 60 * 24 * 365))) * 60 * 60 * 24 * 1000 * 365);
				break;
			default :
				break;
		}
		return currentTimePoint;
		
	}
}
