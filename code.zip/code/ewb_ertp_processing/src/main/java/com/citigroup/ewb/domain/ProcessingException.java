package com.citigroup.ewb.domain;

public class ProcessingException extends Exception {
    public ProcessingException(String message) {
        super(message);
    }
}
