package com.citigroup.ewb.domain.components;

import java.util.List;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Predicate;
import org.apache.kafka.streams.kstream.Produced;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.ConditionModel;
import com.citigroup.ewb.model.FilterModel;

public class C_Filter<T,S> extends EventTransformer<KStream<String, Event>,KStream<String, Event>>{

	private static final int AND = 1;
	private static final int OR = 0;
	
	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		int logicop = AND;
		FilterModel m = (FilterModel)this.model;
		ConditionModel[] conditions = m.getConditions();
		String relation = m.getRelation();
		if(relation.equalsIgnoreCase("and")) logicop = AND;
		else logicop = OR;
		
		Predicate<String, Event>[] ps = new Predicate[conditions.length];
		int i =0;
		for(ConditionModel cm : conditions) {
			ps[i] = FilterFunctions.generatePredicate(cm);
			i++;
		}
		
		KStream filteredevents = null;
		KStream leftevents = events;
		for (Predicate<String, Event> p : ps) {
			if (logicop == AND) {
				filteredevents = leftevents.filter(p);
				leftevents = filteredevents;
			}
			else if (logicop == OR) {
				if (filteredevents == null)
					filteredevents = leftevents.filter(p);
				else 
					filteredevents = filteredevents.merge(leftevents.filter(p));
				leftevents = leftevents.filterNot(p);
			}
		}
	    
		configureDownstreamTopology(builder, filteredevents, keySerde, valueSerde);
//		return filteredevents;
	};
	
	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}
}
