package com.citigroup.ewb.model;

public abstract class Model {
	protected String modelId;
	protected Long versionId;
	
}
