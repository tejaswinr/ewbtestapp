package com.citigroup.ewb.domain;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.KeyValueMapper;
import org.apache.kafka.streams.kstream.Predicate;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.QueryableStoreType;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.apache.kafka.streams.state.StoreBuilder;

import com.citigroup.ewb.avro.Event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citigroup.ewb.config.ProcessingStreamingConfig;
import com.citigroup.ewb.domain.components.*;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.ProfileUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class ProcessStream {
	
	static final String TRADEEXCEPTION_EVENT = "TradeExceptionEvent";
	
	@Autowired
	ProcessingStreamingConfig config;
	
	@Autowired
	C_Analysis analysisEngine;
	
	KafkaStreams kafkaStreams;
	static AtomicLong totalProcessedEvents = new AtomicLong(0L);
	
	Serde stringSerde;// = Serdes.String();
    Serde eventSerde;// = Serdes.serdeFrom(Event.class);

    protected static AtomicLong eventClock = new AtomicLong(-1L);
    
    public KafkaStreams getKafkaStreams() {
    	return kafkaStreams;
    }
    
    public ReadOnlyKeyValueStore getStateStore(String name) {
    	return kafkaStreams.store(name + ".aggregator.store", QueryableStoreTypes.keyValueStore());
    }

    public Map[] getAllKeyValuePairs(String name) {
    	AnalysisModel model = this.analysisEngine.getAnalysisModel();
    	MeasureModel mm = model.getMeasureModel(name);
    	String[] keys = model.getMeasureModelKeys(name);
    	List<Map> allvalues = new ArrayList<Map>();
    	// Get the values for a range of keys available in this application instance
    	ReadOnlyKeyValueStore keyValueStore = this.getStateStore(name);
    	KeyValueIterator<String, Long> all = keyValueStore.all();
    	while (all.hasNext()) {
    	  Map newrow = null;
    	  KeyValue<String, Long> next = all.next();
    	  
    	  System.out.println("count for " + next.key + ": " + next.value);
    	  newrow = ProfileUtil.parseKeyValue( mm, next.key,  next.value.toString());
    	  if (newrow.size()>0)
    		  allvalues.add(newrow);
    	}
    	Map[] rtnmap = new LinkedHashMap[allvalues.size()];
    	int i=0;
    	for(Map m: allvalues) {
    		rtnmap[i] = m;
    		i++;
    	}
    	return rtnmap;
    }
    
    public Map[] getTotalKeyValuePairs(String name) {
    	
    	AnalysisModel model = this.analysisEngine.getAnalysisModel();
    	MeasureModel mm = model.getMeasureModel(name);
    	String[] keys = model.getMeasureModelKeys(name);
    	List<Map> allvalues = new ArrayList<Map>();
    	// Get the values for a range of keys available in this application instance
    	ReadOnlyKeyValueStore keyValueStore = this.getStateStore(name);
    	KeyValueIterator<String, Long> all = keyValueStore.all();
    	while (all.hasNext()) {
      	  	KeyValue<String, Long> next = all.next();
    		Map newrow = ProfileUtil.parseTotalKeyValue(mm,  next.key, next.value.toString());
    		if (newrow.size()>0)
    			allvalues.add(newrow);
    	}
    	Map[] rtnmap = new LinkedHashMap[allvalues.size()];
    	int i=0;
    	for(Map m: allvalues) {
    		rtnmap[i] = m;
    		i++;
    	}
    	return rtnmap;
    }
    
    public static void updateEventClock(long newtime) {
    	synchronized(eventClock) {
	    	if (newtime > eventClock.get()) 
	    		eventClock.set(newtime);
	    	}
    }
    
    public static long getEventClock() {
    	return eventClock.get();
    }
        
    public static AtomicLong getTotalProcessedEvents() {
    	return totalProcessedEvents;
    }
	
	/**
	 * @startuml
	 * start
	 * :new StreamsBuilder;
	 * :build source stream(core system topic);
	 * :config.getProcessorTopics();
	 * while(more processorname available)
	 * :next processorname;
	 * :find topic;
	 * :configure processing topology for current topic&processor;
	 * end while
	 * stop
	 * @enduml
	 */
	/**
	 * Define the processing topology
	 * @return
	 * @throws ProcessingException 
	 */
	public KafkaStreams buildEventStreams() throws ProcessingException {

		if (!this.analysisEngine.isModelReady())
			throw new ProcessingException("Model is not ready");
		
	    final StreamsBuilder builder = new StreamsBuilder();
	    // read the source stream
	    
	    Thread.currentThread().setContextClassLoader(null);
	    
	    String eventserdename = config.properties().getProperty(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG);
	    System.out.print("\r\nevent serde: " + eventserdename);

	    String stringserdename = config.properties().getProperty(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG);
	    System.out.print("\r\nkey serde: " + stringserdename);

	    try {
			this.stringSerde = (Serde) Class.forName(stringserdename).newInstance();
			this.eventSerde = (Serde) Class.forName(eventserdename).newInstance();
			
			Map<String, String> props = new HashMap<>();
			props.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, config.schemaregistryurl);
			stringSerde.configure(props, true);
			eventSerde.configure(props, false);

			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProcessingException("Serialization is not properly initialized");
		} catch (IllegalAccessException e) {
			// TODO Auto-gener	ated catch block
			e.printStackTrace();
			throw new ProcessingException("Serialization is not properly initialized");			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProcessingException("Serialization is not properly initialized");			
		}
	    Serde<byte[]> bytesSerde = Serdes.ByteArray();
	    KStream<String, Event> events = builder.stream(config.processingtopic);
	    
/*	    KStream<String, Event>[] partitioned = input.branch(
	    	    (k, v) -> {
	    	      boolean isValidRecord = false;
	    	      try {
	    	    	stringSerde.deserializer().deserialize(config.processingtopic, k);
	    	        eventSerde.deserializer().deserialize(config.processingtopic, v);
	    	        isValidRecord = true;
	    	      }
	    	      catch (SerializationException ignored) {}
	    	      return isValidRecord;
	    	    },
	    	    (k, v) -> true
	    	);
*/
	    	// partitioned[0] is the KStream<byte[], byte[]> that contains
	    	// only valid records.  partitioned[1] contains only corrupted
	    	// records and thus acts as a "dead letter queue".
/*	    	KStream<String, Event> events = partitioned[0].map(
	    	    (key, value) -> KeyValue.pair(
	    	        // Must deserialize a second time unfortunately.
	    	        (String)(stringSerde.deserializer().deserialize(config.processingtopic, key)),
	    	        (Event)eventSerde.deserializer().deserialize(config.processingtopic, value)));

	    	// Don't forget to actually write the dead letter queue back to Kafka!
	    	partitioned[1].to(Serdes.ByteArray(), Serdes.ByteArray(), "quarantine-topic");	    
	*/    
	    this.configureProcess(builder, events);
/*	    for (String processorname : processors.keySet() ) {
	    	String topicname = processors.get(processorname);
	    	this.configureProcess(processorname, topicname, events);
	    }*/
	    
	    return new KafkaStreams(builder.build(), config.properties());		
	}
	
	/**
	 * @startuml
	 * start
	 * :get key SerDe and value SerDe;
	 * :configure lambda expression to filter out events;
	 * :filter out events with lambda expression;
	 * :routes events to its topic with proper key SerDe and value SerDe;
	 * end
	 * @enduml
	 */
	/**
	 * configure real time streaming process per topic per processor
	 * @param processorname
	 * @param topicname
	 * @param events
	 * @throws ProcessingException 
	 */
	public void configureProcess(StreamsBuilder builder, KStream<String, Event> events) throws ProcessingException {

//	    Predicate<String, Event> isForThisProcessor = null;//(k, v) -> v.getEXCEPTIONSOURCE().toString().toLowerCase().hashCode() == processorname.toLowerCase().hashCode();
	    
//	    KStream routedEvents = events.filter(isForThisProcessor);
	    events.foreach(new ForeachAction<String, Event>() {
	        public void apply(String key, Event value) {
	            System.out.println("check value: " + key + ": " + value + "\r\n");
	            totalProcessedEvents.addAndGet(1L);
	        }
	     });

	    this.analysisEngine.configureProcessingTopology(builder, events, null,null);
//	    System.out.print("route event to topic - '" + topicname + "' for processor : '" + processorname + "'\r\n");
	   
//	    routedEvents.to(topicname, Produced.with(stringSerde, eventSerde));
		
	}
	
    /**
     * Now that we have finished the definition of the processing topology we can actually run
     * it via `start()`.  The Streams application as a whole can be launched just like any
     * normal Java application that has a `main()` method.
     * @throws Exception
     */
	public void startStreaming() throws Exception {
    
        final KafkaStreams streams = buildEventStreams();
        this.kafkaStreams = streams;
        
        // Always (and unconditionally) clean local state prior to starting the processing topology.
        // We opt for this unconditional call here because this will make it easier for you to play around with the example
        // when resetting the application for doing a re-run (via the Application Reset Tool,
        // http://docs.confluent.io/current/streams/developer-guide.html#application-reset-tool).
        //
        // The drawback of cleaning up local state prior is that your app must rebuilt its local state from scratch, which
        // will take time and will require reading all the state-relevant data from the Kafka cluster over the network.
        // Thus in a production scenario you typically do not want to clean up always as we do here but rather only when it
        // is truly needed, i.e., only under certain conditions (e.g., the presence of a command line flag for your app).
        
        streams.cleanUp();
        System.out.print(Thread.currentThread().getName() + ": Start streaming ...");
        streams.start();
        
        // Add shutdown hook to respond to SIGTERM and gracefully close Kafka Streams
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
          @Override
          public void run() {
            streams.close();
            kafkaStreams = null;
          }
        }));   
    }
	
	public void stopStreaming() throws Exception {
		if (kafkaStreams != null)
			this.kafkaStreams.close();
	}
}
