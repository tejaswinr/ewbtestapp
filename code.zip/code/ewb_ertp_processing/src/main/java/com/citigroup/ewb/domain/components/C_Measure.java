package com.citigroup.ewb.domain.components;

import java.util.List;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessStream;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.ProfileUtil;
import com.citigroup.ewb.util.TimeUtil;

public class C_Measure<T, S> extends  EventTransformer<KStream<String, Event>,KStream<String, Event>> {

	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		
		MeasureModel m = (MeasureModel)this.model;
		
		events.foreach(new ForeachAction<String, Event>() {
	        public void apply(String key, Event value) {
	        	long eventtime = value.getCreatedDate();
	        	ProcessStream.updateEventClock(eventtime);
	        	String timeunit = m.getUnit();
	        	long profiletime = TimeUtil.calculateStartingTime(timeunit, eventtime);
	        	try {
					String profilekey = generateProfileKey(value, profiletime);
					System.out.print("new event" + ": " + profilekey + "\n");
					value.setProfileKey(profilekey);

				} catch (ProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	value.setProfileTime(profiletime);
	        }
	     });

		configureDownstreamTopology(builder, events, keySerde, valueSerde);
	}
	private String generateProfileKey(Event e, long profiletime) throws ProcessingException {
		StringBuffer pkey = new StringBuffer("");
		MeasureModel m = (MeasureModel)this.model;
		String[] aggregatefields = m.getGroup_fields();
		for (String field : aggregatefields) {
			String fieldname = AnalysisModel.parseField(field);
			Object v = null;
			if (e.getSchema().getField(fieldname) != null)
				v = e.get(fieldname);
			else {
				String profile = (String)e.get(ProfileUtil.PROFILEFIELD);
				System.out.print("profile string: " + profile);
				v = ProfileUtil.getProfileValue(profile, fieldname);
			}
			if (v==null) v = new String("");
			System.out.print(fieldname + ": " + v + "\n");
			pkey.append(v.toString()).append("#");
		}
		String bucketfield = m.getBucket_field();
		String[] bucketcriteria = m.getBucket_criteria();
		if(bucketfield != null && bucketfield.trim().length()>0) {
			Double value = Double.valueOf(e.get(AnalysisModel.parseField(bucketfield.trim())).toString());
			int bucket = this.calculateBucket(bucketcriteria, value);
			pkey.append(bucket);
			//TBD: bucket on profile field
		}
		pkey.append("#").append(profiletime);
		System.out.print("Profile Key: " + pkey.toString() + "\n");
		return pkey.toString();
	}
	
	private int calculateBucket(String[] bucketcriteria, Double value) throws ProcessingException {
		if (bucketcriteria == null || bucketcriteria.length<=0) throw new ProcessingException("empt bucket criteria");
		if (value < Double.valueOf(bucketcriteria[0])) return 0;
		else if (value >= Double.valueOf(bucketcriteria[bucketcriteria.length-1])) return bucketcriteria.length-1;
		int i = 0;
		for (i=1; i<bucketcriteria.length; i++) {
			Double bucketright = Double.valueOf(bucketcriteria[i]);
			if (value <= bucketright) break;
		}
		return i;
	}
}
