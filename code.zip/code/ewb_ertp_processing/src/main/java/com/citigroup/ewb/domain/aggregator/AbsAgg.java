package com.citigroup.ewb.domain.aggregator;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;

import com.citigroup.ewb.avro.Event;

public abstract class AbsAgg<T> {
	
	public static final String MAX = "max";
	public static final String MIN = "min";
	public static final String CNT = "cnt";
	public static final String SUM = "sum";
	
	public static Map<String, String> aggFunMap = new HashMap<String, String>();
	
	static {
		addAggFunction(MAX, "com.citigroup.ewb.domain.aggregator.MaxAgg");
		addAggFunction(MIN, "com.citigroup.ewb.domain.aggregator.MinAgg");
		addAggFunction(CNT, "com.citigroup.ewb.domain.aggregator.CntAgg");
		addAggFunction(SUM, "com.citigroup.ewb.domain.aggregator.SumAgg");
	}
	
	public static String getAggClass(String aggfun) {
		return aggFunMap.get(aggfun);
	}
	
	public static void addAggFunction(String aggfun, String classname) {
		aggFunMap.put(aggfun, classname);
	}
	
	public abstract KTable CalculateTopology(KStream<String, Event> events, String measureType, String field) ;
	
	public abstract Serde getKeySerde();
	
	public abstract Serde getValueSerde();
	
	public abstract T calculate(T t1, T t2);
	
	public static AbsAgg getAggInstance(String aggname) {
	    String classname = AbsAgg.getAggClass(aggname);
	    Class<?> aggClass = null;
		try {
			aggClass = Class.forName(classname);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    AbsAgg agg = null;
		try {
			agg = (AbsAgg)aggClass.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return agg;
	}
}
