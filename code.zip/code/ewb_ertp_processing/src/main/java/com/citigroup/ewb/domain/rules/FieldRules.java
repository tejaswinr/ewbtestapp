package com.citigroup.ewb.domain.rules;

import java.util.Random;

import com.citigroup.ewb.avro.Event;

public interface FieldRules {
	public String r_field_severity(Event e);
}
