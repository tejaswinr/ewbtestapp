package com.citigroup.ewb.domain.components;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Predicate;
import org.apache.kafka.streams.processor.Processor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.processor.StateStoreSupplier;
import org.apache.kafka.streams.state.KeyValueBytesStoreSupplier;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyWindowStore;
import org.apache.kafka.streams.state.Stores;
import org.apache.kafka.streams.state.Stores.KeyValueFactory;
import org.apache.kafka.streams.state.Stores.PersistentKeyValueFactory;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessStream;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.domain.aggregator.AbsAgg;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.ProfileUtil;
import com.citigroup.ewb.util.TimeUtil;

public class C_WindowAggregator<T, S> extends EventTransformer<KStream<String, S>,KStream<String, S>> implements Processor<String, S>
{
//	  private KeyValueStore<String, S> summaryStore;
	  S total = null;
	  Set<String> newkeys = new HashSet<String>();
	  KeyValueStore<String, S> summaryStore;
	  ProcessorContext context;	  
	  
	  String frontendSvcUrl;
	  public void setFrontendSvcUrl(String url) {
		  this.frontendSvcUrl = url;
	  }
	  @Override
	  @SuppressWarnings("unchecked")
	  public void init(ProcessorContext context) {
	      this.context = context;
		  MeasureModel m = (MeasureModel) this.model;
		  summaryStore = (KeyValueStore<String, S>) this.context.getStateStore(m.getType()+".aggregator.store");
		  System.out.print("init C_WindowAggregator processor\n");
	  }
	  
	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, S> events, Serde keySerde, Serde valueSerde)
			throws ProcessingException {
		// TODO Auto-generated method stub
		
		MeasureModel m = (MeasureModel)this.model;
		
/*		KeyValueBytesStoreSupplier countStoreSupplier = Stores.inMemoryKeyValueStore(m.getType()+".aggregate.store");
		StateStoreBuilder builder = Stores.keyValueStoreBuilder(countStoreSupplier,
				keySerde.getClass(),
				valueSerde.getClass()).withLoggingDisabled();
		builder.addStateStore(builder);
		S v;
*/

	/*	KeyValueFactory<? extends Serde, ? extends Serde> baseKVFactory = Stores.create(m.getType() + ".aggregate.store")
				.withKeys(keySerde.getClass())
				.withValues(valueSerde.getClass());
	
		Stores.InMemoryKeyValueFactory<? extends Serde, ? extends Serde> inMemoryKVFactory = baseKVFactory.inMemory(); //ON-heap
		StateStoreSupplier imMemoryStateStoreSupplier = inMemoryKVFactory.build();
		*/
		
		/*PersistentKeyValueFactory<? extends Serde, ? extends Serde> persistentKVFactory = baseKVFactory.persistent(); //OFF-heap
		StateStoreSupplier persistentStateStoreSupplier = persistentKVFactory.build();*/
		
/*	    String field = m.getField();
	    String aggname = m.getAggregator();
	    String classname = AbsAgg.getAggClass(aggname);
	    Class<?> aggClass;
		try {
			aggClass = Class.forName(classname);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProcessingException("Can not find class: " + classname);
		}
	    AbsAgg agg;
		try {
			agg = (AbsAgg)aggClass.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProcessingException("Can not create new instance of class: " + classname);
		}
		
*/		
		Long window = m.getWindow();

    	long eventclock = ProcessStream.getEventClock();
    	String timeunit = m.getUnit();
    	Predicate<String, S>  ps = (k, v) -> {
			String[] keys = k.split("#");
			long profiletime = Long.valueOf(keys[keys.length -1]);
			return (eventclock - profiletime <= TimeUtil.calculateWindowRange(timeunit, window));
		};
		
		KStream filteredevents = events.filter(ps);
	    String aggname = m.getAggregator();
	    AbsAgg agg = AbsAgg.getAggInstance(aggname);
		
	    filteredevents.process(() -> this, m.getType()+".aggregator.store") ;
		
/*		filteredevents.foreach(new ForeachAction<String, S>() {
	        public void apply(String key, S value) {
	        	// calculate summary for each group/bucket+timeunit by incremental calculation
	        	//newkeys.add(ProfileUtil.getProfileKeyWithoutTime(key));
	        	String k = ProfileUtil.getProfileKeyWithoutTime(key);
				System.out.print("Calculate total for key: " + k);
				S total = null;
		    	long currenttime = ProcessStream.getEventClock();
		    	currenttime = TimeUtil.calculateStartingTime(timeunit, currenttime);
				long unittime = TimeUtil.calculateWindowRange(timeunit, 1);
		    	for (int i=0;i<window;i++) {
		    		String profilekey = k+String.valueOf(currenttime);
		    		S v = summaryStore.get(profilekey);
		    		if (profilekey.equals(key))
		    			v=value;
		    		if (v!=null) {
						System.out.print("Time: " + profilekey);
		    			System.out.print("  value: " + v.toString() + "\n");
		    		}

		    		total = (S)agg.calculate(total,  v);
		    		currenttime = currenttime - unittime;
		    	}
				System.out.print("total value : " + total+ "\n");	    	
		    	summaryStore.put("total#" + k, total);
	        }
	     });
		
*/
/*	    String aggname = m.getAggregator();
	    AbsAgg agg = AbsAgg.getAggInstance(aggname);
		
		for (String k : this.newkeys) {
			System.out.print("Calculate total for key: " + k);
			S total = null;
	    	long currenttime = eventclock;
			long unittime = TimeUtil.calculateWindowRange(timeunit, 1);
	    	for (int i=0;i<window;i++) {
	    		String profilekey = k+"#" + String.valueOf(currenttime);
	    		S v = summaryStore.get(profilekey);
	    		total = (S)agg.calculate(total,  v);
	    		currenttime = currenttime - unittime;
	    	}
			System.out.print(". value : " + total);	    	
	    	summaryStore.put("total#" + k, total);
		}*/
		this.configureDownstreamTopology(builder, events, keySerde, valueSerde);
	}


	@Override
	public KStream<String, S> transform(KStream<String, S> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void process(String key, S value) {
		// TODO Auto-generated method stub
		System.out.print("process: key = " + key + ". value = " + value + "\n");
		MeasureModel m = (MeasureModel)this.model;
	    String field = m.getField();
	    String aggname = m.getAggregator();
	    AbsAgg agg = AbsAgg.getAggInstance(aggname);
		
		Long window = m.getWindow();
    	long eventclock = ProcessStream.getEventClock();
    	String timeunit = m.getUnit();
		
    	// calculate with historic values
	
		S vs = summaryStore.get(key);
		S newValue = value;
		if (vs==null) {
			// try to load from db. TBD
			System.out.print("old value = 0" +  "\n");  
			newValue = (S)agg.calculate(vs, value);
			System.out.print("new value = " + newValue.toString() + "\n");  
		}
		else {
			//no need to do anything.	
			System.out.print("value = " + vs.toString() + "\n");  
		}
		summaryStore.put(key, newValue);
		
    	String k = ProfileUtil.getProfileKeyWithoutTime(key);
		System.out.print("Calculate total for key: " + k);
		S total = null;
    	long currenttime = ProcessStream.getEventClock();
    	currenttime = TimeUtil.calculateStartingTime(timeunit, currenttime);
		long unittime = TimeUtil.calculateWindowRange(timeunit, 1);
    	String tk = "total#" + k;
		S currentvalue = summaryStore.get(tk);
    	for (int i=0;i<window;i++) {
    		String profilekey = k+String.valueOf(currenttime);
    		S v = summaryStore.get(profilekey);
    		if (profilekey.equals(key))
    			v=value;
    		if (v!=null) {
				System.out.print("Time: " + profilekey);
    			System.out.print("  value: " + v.toString() + "\n");
    		}
/*		    		else 
    			System.out.print("  value: 0\n");*/

    		total = (S)agg.calculate(total,  v);
    		currenttime = currenttime - unittime;
    	}
		System.out.print("total value : " + total+ "\n");
		if (currentvalue == null || !total.toString().equalsIgnoreCase(currentvalue.toString())) {
	    	summaryStore.put(tk, total);
	    	this.post(tk, total.toString());
		}
	}

	private void post(String key, String value) {
//		String changeeventpublisherurl = "http://localhost:8080/api/v1/wallets/balance";
		System.out.print("post to : " + frontendSvcUrl);
		System.out.print( key + ": " + value);
		MeasureModel m = (MeasureModel)this.model;
		
		Map analysisresultmap =  ProfileUtil.parseTotalKeyValue(m, key, value);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");

		System.out.print( "Map : " + analysisresultmap.toString());

		if (analysisresultmap.size()<1) return;		

		JSONObject json = new JSONObject();
		
		Iterator keyindex = analysisresultmap.keySet().iterator();
		while (keyindex.hasNext()) {
			Object k = keyindex.next();
			Object tmp= analysisresultmap.get(k);
			String v = new String("");
			if (tmp!=null)
				v = tmp.toString();
			json.put((String)k, v);
		}

		System.out.print("json : " + json.toString());
		
		HttpEntity <String> httpEntity = new HttpEntity <String> (json.toString(), httpHeaders);

		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject(frontendSvcUrl, httpEntity, String.class);

//		JSONObject jsonObj = new JSONObject(response);
//		String balance = jsonObj.get("data").toString();
		System.out.print("response: " + response);
	}
	
	@Override
	public void punctuate(long arg0) {
		// TODO Auto-generated method stub
		
	}

}
