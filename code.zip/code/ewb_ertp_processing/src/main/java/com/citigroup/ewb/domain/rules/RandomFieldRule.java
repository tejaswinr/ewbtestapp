package com.citigroup.ewb.domain.rules;

import java.util.Random;

import com.citigroup.ewb.avro.Event;

public class RandomFieldRule implements FieldRules{

	@Override
	public String r_field_severity(Event e) {
		// TODO Auto-generated method stub
		long time = System.currentTimeMillis();
		Random r = new Random(time);
		int c = r.nextInt(4);
		String severity = "Critical";
		switch(c) {
			case 0 : 
				severity = new String("Critical");
				break;
			case 1 : 
				severity = new String("High");
				break;
			case 2 : 
				severity = new String("Medium");
				break;
			case 3 : 
				severity = new String("Low");
				break;
			default : 
				break;
		}
		return severity;
	}

}
