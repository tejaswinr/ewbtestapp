package com.citigroup.ewb;

import java.util.concurrent.Executor;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication
@EnableAsync
public class EWBProcessingApplication {
	private static final Logger logger = LogManager.getLogger(EWBProcessingApplication.class);
	public static void main(String[] args) {
			SpringApplication app = new SpringApplication(EWBProcessingApplication.class);
			app.run(args);

    }
	
	 @Bean(name="processExecutor") 
     public TaskExecutor workExecutor() { 
		 ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor(); 
         threadPoolTaskExecutor.setThreadNamePrefix("EWBTrading-"); 
	     threadPoolTaskExecutor.setCorePoolSize(3); 
	     threadPoolTaskExecutor.setMaxPoolSize(3); 
	     threadPoolTaskExecutor.setQueueCapacity(600); 
	     threadPoolTaskExecutor.afterPropertiesSet(); 
         logger.debug("Start ThreadPool for processing..."); 
         return threadPoolTaskExecutor; 
     } 

}
