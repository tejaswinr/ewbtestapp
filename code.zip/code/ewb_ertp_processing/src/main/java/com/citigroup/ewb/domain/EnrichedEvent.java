package com.citigroup.ewb.domain;

import java.util.Map;

import com.citigroup.ewb.avro.Event;

public class EnrichedEvent extends Event {
	long profiletime;
	Map profileMap;
	public void setProfiletime(long newtime) {
		this.profiletime = newtime;
	}
	public long getProfiletime() {
		return this.profiletime;
	}
	public void setprofileMap(Map pmap) {
		this.profileMap = pmap;
	}
	public Map getProfileMap() {
		return this.profileMap;
	}
}
