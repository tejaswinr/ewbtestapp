package com.citigroup.ewb.domain.components;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.Schema.Field;
import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlContext;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.JexlExpression;
import org.apache.commons.jexl3.MapContext;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.json.JSONObject;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.domain.ProcessStream;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.domain.rules.FieldRules;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.EnrichmentModel;
import com.citigroup.ewb.model.MeasureModel;
import com.citigroup.ewb.util.ProfileUtil;
import com.citigroup.ewb.util.TimeUtil;
 
public class C_EventEnricher<T, S> extends EventTransformer<KStream<String, Event>,KStream<String, Event>> {

    JexlEngine jexl;
    JexlExpression[] jexp = null;
	String fieldRule;
	
	public void setFieldRule(String rule) {
		this.fieldRule = rule;
	}
	
    public void initialize() throws ProcessingException {
		
    	AnalysisModel m = (AnalysisModel)this.model;

    	Map<String, Object> funcs = new HashMap<String, Object>();

    	FieldRules rules = null;
		try {
			rules = (FieldRules)Class.forName(fieldRule).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        funcs.put("rules", rules);
        jexl = new JexlBuilder().namespaces(funcs).create();

//    	String jexlExp = "(120.0-($Event.PROFILE_TIME - $Event.CREATED_DATE)/1000.0/60.0)/60.0";
//        JexlExpression e = jexl.createExpression( jexlExp );
    	
        EnrichmentModel[] ems = m.getEnrichments();
        if (ems == null || ems.length <1) return;
        jexp = new JexlExpression[ems.length];
        
    	int i=0;
    	for (EnrichmentModel em : ems) {
    		String expression = em.getExpression();
    		System.out.print("parse exception: " + expression + "\n");
    		jexp[i] = jexl.createExpression( expression );
    		i++;
    	}

    }
    
    private List<String> getVariables(String expression) {
    	String[] allstrs = expression.split(" "); //expecting at least a space character between a variable and other elements
    	List<String> variables = new ArrayList();
    	for (String part : allstrs) {
    		if (part.startsWith("$")) variables.add(part);
    	}
    	return variables;
    }
    
    public static void initializeJexlContext (JexlContext jc, Event e) {
    	jc.set("$Event", e);
    	final LocalDateTime startOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
    	final Date startOfDayAsDate = Date.from(startOfDay.toInstant(ZoneOffset.UTC));
    	jc.set("$sysdate", startOfDayAsDate.getTime());
    	int size = e.getSchema().getFields().size();
    	for (int i = 0 ; i< size; i++) {
    		String fieldName = e.getSchema().getFields().get(i).name();
    		if (e.get(fieldName)!=null) {
	        	jc.set("$Event."+fieldName, e.get(fieldName));
	        	System.out.print("add $Event."+fieldName + " : " + e.get(fieldName).toString());
    		}
    	}
    }

    
	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		// TODO Auto-generated method stub
		AnalysisModel m = (AnalysisModel)this.model;
//        Event event = EventGenerator.getNext();  
        JexlContext jc = new MapContext();

		events.foreach(new ForeachAction<String, Event>() {
	        public void apply(String key, Event value) {
	        	
	        	C_EventEnricher.initializeJexlContext (jc, value);	        
	        	EnrichmentModel[] ems = m.getEnrichments();
	        	if (ems == null) return;
	        	for (int i=0; i< ems.length ; i++) {
	        		System.out.print("evaluate exp: " + jexp[i].getSourceText()+"\n");
	                Object o = jexp[i].evaluate(jc);
		        	String field = ems[i].getField();
		        	String type = ems[i].getType();
		        	if (value.getSchema().getField(field) != null) {
		        		value.put(field,  o);
		        		System.out.print("set enriched field: " + field + ": " + o.toString());
		        	}
		        	else {
		        		// fields in profiles
		        		String profile = (String)value.get(ProfileUtil.PROFILEFIELD);
		        		if (profile == null || profile.length()<1) {
		        			profile = ProfileUtil.createNewProfile(field, o.toString(), type);
		        		}
		        		else
		        			profile = ProfileUtil.updateProfile(profile, field, o.toString(), type);
		        		value.put(ProfileUtil.PROFILEFIELD, profile);
		        		System.out.print("profile: " + profile);
		        	}
	        	}
	        }
	     });
		
		configureDownstreamTopology(builder, events, keySerde, valueSerde);
	}

	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
