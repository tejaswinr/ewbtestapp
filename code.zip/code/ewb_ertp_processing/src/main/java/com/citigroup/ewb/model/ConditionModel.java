package com.citigroup.ewb.model;

import com.citigroup.ewb.avro.Event;

/**
 * 	 The class is to hold a condition defined with similar structure to below
 *   {
 *       "field": "$event.category",
 *       "function": "equals",
 *       "parameters": [
 *            "BUSINESS_VALIDATION"
 *       ]
 *   }
 * @author zh22901
 *
 */
public class ConditionModel  extends Model {
	
	String field;
	String function;
	String[] parameters;
	
	public void setField(String field) {
		this.field = field;
	}
	
	public String getField() {
		return this.field;
	}
	
	public void setFunction(String function) {
		this.function = function;
	}
	
	public String getFunction() {
		return this.function;
	}
	
	public void setParameters(String[] parameters) {
		this.parameters = parameters;
	}
	
	public String[] getParameters() {
		return this.parameters;
	}

	public static ConditionModel generateSampleCondition() {
		ConditionModel c = new ConditionModel();
		c.field = "$Event.ERROR_CATEGORY";
		c.function = "Equals";
		String[] parameters = new String[1];
		parameters[0]="Missing Security Setup";
		c.parameters=parameters;
		return c;
	}
}
