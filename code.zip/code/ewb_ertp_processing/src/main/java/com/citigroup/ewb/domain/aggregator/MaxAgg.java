package com.citigroup.ewb.domain.aggregator;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.kstream.Aggregator;
import org.apache.kafka.streams.kstream.Initializer;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.DoubleSerde;
import com.citigroup.ewb.common.util.StringSerde;
import com.citigroup.ewb.util.ProfileUtil;

public class MaxAgg extends AbsAgg<Double> {

	@Override
	public KTable CalculateTopology(KStream<String, Event> events, String type, String field) {

		KGroupedStream<String, Event> groupedData = events.groupBy((key, value) -> value.get(ProfileUtil.PROFILEKEYFIELD).toString()); 
		Serde doubleSerde = null;
		KTable maxTable = groupedData.aggregate(new Initializer<Double>() {
	        public Double apply() {
	            return 0.0;
	        }
	    }, new Aggregator<String, Event, Double>() {

	        @Override
	        public Double apply(String aggKey, Event value, Double currentmax) {
	        	Double v = (Double) (value.get(field)) ;
	            return   v > currentmax ? v : currentmax;
	        }
	    }, doubleSerde);
	    
	    return maxTable;
	}

	@Override
	public Serde getKeySerde() {
		// TODO Auto-generated method stub
		return new StringSerde();
	}

	@Override
	public Serde getValueSerde() {
		// TODO Auto-generated method stub
		return new DoubleSerde();
	}

	@Override
	public Double calculate(Double t1, Double t2) {
		// TODO Auto-generated method stub
		if (t1 == null) t1 = Double.NEGATIVE_INFINITY;
		if (t2 == null) t2 = Double.NEGATIVE_INFINITY;		
		
		if (t1 > t2) return t1;
		else return t2;
	}

}
