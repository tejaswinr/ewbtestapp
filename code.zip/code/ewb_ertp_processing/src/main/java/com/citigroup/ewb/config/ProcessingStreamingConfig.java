package com.citigroup.ewb.config;

import java.util.Properties;

import org.apache.log4j.LogManager; 
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import org.apache.kafka.clients.consumer.ConsumerConfig;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;

import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.errors.LogAndContinueExceptionHandler;

@Configuration
public class ProcessingStreamingConfig {
	
	Logger logger = LogManager.getLogger(ProcessingStreamingConfig.class);
	
	@Autowired
	private Environment evn;
	
	@Value("${processing.topic:trading}")
	public String processingtopic;
	
	@Value("${processing.streaming.application.id:ewb-trading}")
	public String applicationid;
	
	@Value("${bootstrap.servers:sd-9a28-ab9d:9092}")
	public String bootstrapservers;

	@Value("${processing.streaming.client.id:trading}")
	public String clientid;

	@Value("${schema.registry.url:http://sd-9a28-ab9d:8081}")
	public String schemaregistryurl;

	@Value("${processing.streaming.default.key.serde:org.apache.kafka.common.serialization.Serdes.StringSerde}")
	public String defaultkeyserde;	
		
	@Value("${processing.streaming.default.value.serde:com.citigroup.ewb.common.util.SpecificAvroSerde}")
	public String defaultvalueserde;

	@Value("${processing.streaming.state.dir:/home/zh22901/workspace}")
	public String statedir;
	
	@Value("${processing.streaming.auto.offset.reset:earliest}")
	public String autooffsetreset;

	@Value("${processing.streaming.commit.interval.ms:1000}")
	public String commitintervalms;
	
	@Value("${processing.streaming.default.deserialization.exception.handler:LogAndContinueExceptionHandler}")
	public String streamingdeserializationexceptionhandler;
	
	public Properties properties() {
	    Properties properties = new Properties();
	    
	    properties.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationid);
	    properties.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapservers);
	    properties.put(StreamsConfig.CLIENT_ID_CONFIG, clientid);
	    properties.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaregistryurl);
	    properties.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, defaultkeyserde);
	    properties.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, defaultvalueserde);
	    properties.put(StreamsConfig.STATE_DIR_CONFIG, statedir);
	    properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autooffsetreset);
	    properties.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, commitintervalms);
	    properties.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, LogAndContinueExceptionHandler.class);
	    
	    return properties;
	}
	
	private void setProperty(String dstkey, String sourcekey, Properties source, Properties p) {
		if (source.getProperty(sourcekey) != null) {
			p.put(dstkey, source.getProperty(sourcekey));
			logger.info(sourcekey + ": " + source.getProperty(sourcekey));
		}
	}

}
