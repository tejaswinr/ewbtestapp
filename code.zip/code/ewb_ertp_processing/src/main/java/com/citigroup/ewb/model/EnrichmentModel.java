package com.citigroup.ewb.model;

/**
 * 
 * @author zh22901
 *
 */
public class EnrichmentModel  extends Model {
	
	String field;
	String type;
	String expression;
	
	public void setField(String field) { 
		this.field = field; 
	}
	
	public String getField() {
		return this.field;
	}
	
	public void setType(String type) { 
		this.type = type; 
	}
	
	public String getType() {
		return this.type;
	}

	public void setExpression(String expression) { 
		this.expression = expression; 
	}
	
	public String getExpression() {
		return this.expression;
	}
	
}
