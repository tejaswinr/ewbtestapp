package com.citigroup.ewb.domain.components;

import java.util.List;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KStream;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;

public class C_Source<T,S> extends EventTransformer<KStream<String, Event>,KStream<String, Event>>{

	@Override
	public void configureProcessingTopology(StreamsBuilder builder, KStream<String, Event> events, Serde keySerde, Serde valueSerde) throws ProcessingException {
		this.configureDownstreamTopology(builder, events, keySerde, valueSerde);
//		return events;
	}

	@Override
	public KStream<String, Event> transform(KStream<String, Event> eventStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
