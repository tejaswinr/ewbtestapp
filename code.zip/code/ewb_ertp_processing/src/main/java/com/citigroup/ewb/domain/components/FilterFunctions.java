package com.citigroup.ewb.domain.components;

import org.apache.avro.Schema.Type;
import org.apache.kafka.streams.kstream.Predicate;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.AnalysisModel;
import com.citigroup.ewb.model.ConditionModel;

public class FilterFunctions {
	
	public static final String STRINGFUNCTION_EQUALS = "equals";
	public static final String STRINGFUNCTION_NOTEQUALS = "not equals";
	public static final String NUMBERFUNCTION_EQUALS = "equals";
	public static final String NUMBERFUNCTION_GREATER = "greater than";
	public static final String NUMBERFUNCTION_LESS = "less than";
	
	public static Predicate<String, Event> generatePredicate(ConditionModel f) throws ProcessingException {
		Predicate<String, Event> p = null;
		String field = AnalysisModel.parseField(f.getField());
		String function = f.getFunction();
		String[] parameters = f.getParameters();
		Type type = Event.getClassSchema().getField(field).schema().getType();
		if (type == Type.STRING) {
			switch(function) {
				case STRINGFUNCTION_EQUALS :
					if (parameters.length != 1 ) throw new ProcessingException("Function: " + function + " parameters length is wrong!");
					p = (k, v) -> v.get(field).toString().equals(parameters[0]);  
					break;
				case STRINGFUNCTION_NOTEQUALS :
					if (parameters.length != 1 ) throw new ProcessingException("Function: " + function + " parameters length is wrong!");
					p = (k, v) -> !v.get(field).toString().equals(parameters[0]);  
					break;
				default :
					break;
			}
		} 
		else if (type == Type.INT || type == Type.DOUBLE || type == Type.FLOAT || type == Type.LONG) {
			if (parameters.length != 1 ) throw new ProcessingException("Length of parameter is wrong");
			switch(function) {
				case NUMBERFUNCTION_EQUALS :
					p = (k, v) -> Double.valueOf(v.get(field).toString()) == Double.valueOf(parameters[0]);  
					break;
				case NUMBERFUNCTION_GREATER :
					p = (k, v) -> Double.valueOf(v.get(field).toString()) > Double.valueOf(parameters[0]);  
					break;
				case NUMBERFUNCTION_LESS :
					p = (k, v) -> Double.valueOf(v.get(field).toString()) < Double.valueOf(parameters[0]);  
					break;
				default :
					break;
			}
		}		
		return p;
	}
}
