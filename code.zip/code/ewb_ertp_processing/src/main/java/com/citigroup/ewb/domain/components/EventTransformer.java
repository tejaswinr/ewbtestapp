package com.citigroup.ewb.domain.components;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.processor.AbstractProcessor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.domain.ProcessingException;
import com.citigroup.ewb.model.Model;

public abstract class EventTransformer<T, S>{

	Model model;
	
	private List<EventTransformer<?,T>> inputLink = new ArrayList<EventTransformer<?,T>>();
	
	private List<EventTransformer<S, ?>> outputLink = new ArrayList<EventTransformer<S,?>>();
	
	public void initialize() throws ProcessingException {
	}

	public abstract void configureProcessingTopology(StreamsBuilder builder, T events, Serde keySerde, Serde valueSerde) throws ProcessingException ;
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
	public void setModel(Model model) {
		this.model = model;
	}
	
	public void registerInput(EventTransformer<?, T> input) {
		System.out.print(input.getClass().getName()  + input.hashCode() + " -> " + this.getClass().getName()  + this.hashCode() + "\n");
		this.inputLink.add(input);
	}
	
	public void registerOutput(EventTransformer<S, ?> output) {
		System.out.print(this.getClass().getName() + this.hashCode() +" -> " + output.getClass().getName() + output.hashCode()  + "\n");		
		this.outputLink.add(output);
	}

	public List<EventTransformer<S, ?>> getOutput() {
		return this.outputLink;
	}
	
	public List<EventTransformer<?, T>> getInput() {
		return this.inputLink;
	}
		
	public void configureDownstreamTopology(StreamsBuilder builder, S eventStream, Serde keySerde, Serde valueSerde) throws ProcessingException {
		
		List<EventTransformer<S, ?>> followers = this.getOutput();
		
		for (EventTransformer<S, ?> next : followers) {
			if (next != null)
				next.configureProcessingTopology(builder, eventStream, keySerde, valueSerde);			
		}
		
	}
	public abstract S transform(T eventStream) ;

	public void cleanUp() {
		this.inputLink.clear();
		this.outputLink.clear();
	}
	
}
