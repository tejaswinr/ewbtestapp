package com.citigroup.ewb.common.util;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.apache.log4j.Logger;

import com.citigroup.ewb.avro.Event;

public class EventTransfer {
    private String content;
    public EventTransfer() {
    }
    public void setContent(String content) {
    	this.content = content;
    }
    public String getContent() {
    	return this.content;
    }
    public Event restoreEvent() throws java.io.IOException {
		System.out.print("\r\nRestore event: " + content);    	
    	byte[] values = content.getBytes(StandardCharsets.UTF_8 );

    	Base64.Decoder dc = Base64.getDecoder();
    	byte[] decoded = dc.decode(values);
    	
    	System.out.print("\r\nbyte arrary length: " + decoded.length);
    	ByteBuffer bb = ByteBuffer.wrap(decoded);
    	
    	return Event.fromByteBuffer(bb);
    }
    public void wrapEvent(byte[] values) {
    	
    	try {
    		System.out.print("\r\nbyte array length: " + values.length);

    		Base64.Encoder codec = Base64.getEncoder();    	
        	
        	byte[] encoded = codec.encode(values);    	
        	    		
			content = new String(encoded, StandardCharsets.UTF_8);
			System.out.print("\r\nWrap event: " + content);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public static String debugEvent(Event e, Logger logger) {
    	StringBuffer log = new StringBuffer("");

		log.append("Debug Event Data: " + "\r\n");
		log.append("transactionId : " + e.getTransactionId() + "\r\n");
		log.append("type : " + e.getFileType() + "\r\n");
		//log.append("tradeId : " + e.getID() + "\r\n");
		log.append("blockId : " + e.getBlockExternalReferenceId() + "\r\n");
		log.append("firmCode : " + e.getFirmCode() + "\r\n");
		log.append("assetClass : " + e.getAssetClass()+ "\r\n");
		log.append("custodian Account: " + e.getCustodianAccount() + "\r\n");
		log.append("source : " + e.getSource() + "\r\n");
	//	log.append("stage : " + e.getStatus() + "\r\n");
		log.append("category : " + e.getExceptionCategory() + "\r\n");
		log.append("description : " + e.getErrorDescription() + "\r\n");
    	
    	if(logger != null) logger.debug(log.toString() + "\r\n");
    	return log.toString();
    }
}
