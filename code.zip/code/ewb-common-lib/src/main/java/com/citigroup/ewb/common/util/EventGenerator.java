package com.citigroup.ewb.common.util;

import com.citigroup.ewb.avro.Event;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class EventGenerator {
    static long numEvents = 10000;
    static long currid = 1;
    static AtomicLong transactionIdGenerator = new AtomicLong(0L);


    static String[] SOURCE = {"MOM","MOTO","TC","MOM","MOTO","TC","MOM","MOTO","TC","MOM"};
    static String[] ASSET_CLASS = {"FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB","FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB"};
    static String[] ALLOCATION_ID = {"OA_OMG1910_A7","OA_OMG1910_A1","OA_OMG1910_A2","OA_OMG1910_A3","OA_OMG1910_A4","OA_OMG1910_A5","OA_OMG1910_A6","OA_OMG1910_A8","OA_OMG1910_A9","OA_OMG1910_A0"};
    static String[] CREATED_BY = {"sy39504","sy39504","sy39504","sy39504","sy39504","tr17063","tr17063","tr17063","tr17063","tr17063"};
    static String[] FIRM_CODE = {"OMGI","KAMES","SLI"};
    static String[] PORTFOLIO_CODE = {"CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG","CBAL for OMG"};
    static String[] ASSET_TYPE_CODE = {"FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB","FXFORWARD","CLIENTIRSWAP","CLIENTCDS","EFL","GB"};
    static String[] ERROR_DESCRIPTION = {"Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx","Could not resolve xxxxx"};

    static String[] Exp_CATEGORY = {"TRADE CAPTURE","CONFIRMATION","SETTLEMENT","ACCOUNTING","DATA DELIVERY"};
    static String[] ERROR_CATEGORY = {"Accounting Exception","Missing Security Setup","Swift Nack","State Street","Missing Mandatory Fields"};
    static String[] FILE_TYPE = {"OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER","OMGI_ALPS_UPLOADER"};
    static String[] BLOCK_EXTERNAL_REFERENCE_ID = {"OA_BT_OMG1910_B1","OA_BT_OMG1910_B2","OA_BT_OMG1910_B3","OA_BT_OMG1910_B4","OA_BT_OMG1910_B5","OA_BT_OMG1910_B6","OA_BT_OM7"};
    static String[] CORESYSTEM={"Core System","NAV","ETF"};
    public static Event getNext() {
        Event tradeFile = new Event();
        Random r = new Random();
        int maxSize = 50;
        long timeStamp = new Date().getTime();
        String empty = "";
        long TRANSACTION_ID  = transactionIdGenerator.incrementAndGet();
        tradeFile.setTransactionId(TRANSACTION_ID);
        tradeFile.setQuantity(r.nextInt(20));
        tradeFile.setCreatedDate(timeStamp);
        tradeFile.setBatchId(Long.valueOf(r.nextInt(maxSize)));
        tradeFile.setSource(SOURCE[r.nextInt(SOURCE.length)]);
        tradeFile.setCustodianAccount(empty);
        tradeFile.setAssetClass(ASSET_CLASS[r.nextInt(ASSET_CLASS.length)]);
        tradeFile.setAllocationId(ALLOCATION_ID[r.nextInt(ALLOCATION_ID.length)]);
        tradeFile.setCreatedBy(CREATED_BY[r.nextInt(CREATED_BY.length)]);
        tradeFile.setFirmCode(FIRM_CODE[r.nextInt(FIRM_CODE.length)]);
        tradeFile.setRemediationStep(empty);
        tradeFile.setPortfolioCode(PORTFOLIO_CODE[r.nextInt(PORTFOLIO_CODE.length)]);
        tradeFile.setExecutingBroker(empty);
        tradeFile.setFilePath(empty);
        tradeFile.setAssetTypeCode(ASSET_TYPE_CODE[r.nextInt(ASSET_TYPE_CODE.length)]);
        tradeFile.setErrorDescription(ERROR_DESCRIPTION[r.nextInt(ERROR_DESCRIPTION.length)]);
        tradeFile.setUpdatedDate(timeStamp);
        tradeFile.setExceptionCategory(Exp_CATEGORY[r.nextInt(Exp_CATEGORY.length)]);
        tradeFile.setErrorCategory(ERROR_CATEGORY[r.nextInt(ERROR_CATEGORY.length)]);
        tradeFile.setFileType(FILE_TYPE[r.nextInt(FILE_TYPE.length)]);
        tradeFile.setBlockExternalReferenceId(BLOCK_EXTERNAL_REFERENCE_ID[r.nextInt(BLOCK_EXTERNAL_REFERENCE_ID.length)]);
        tradeFile.setCoreSystem( CORESYSTEM[r.nextInt(CORESYSTEM.length)]);
        tradeFile.setProfileKey("" );
        tradeFile.setProfileTime(timeStamp);
        tradeFile.setProfile( "" );

        return tradeFile;

    }

}