package com.citigroup.ewb.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.Schema;
import org.apache.log4j.Logger;

import com.citigroup.ewb.avro.Event;

public class EventAvroConverter {

	public static Map toMap(Event e) {
		Map em = new HashMap<String, String>();
		try {
		Schema s = e.getSchema();
		List<Schema.Field> fields = s.getFields();
		for (Schema.Field field : fields) {
			if (field == null) continue;
			System.out.print("Field name = " + field.name());
			Object v = e.get(field.name());
			if (v!=null)
				em.put(field.name(),v.toString());
		}
		}catch (Exception ex) {
			ex.printStackTrace();
		}
		return em;
	}
	
	public static Event mapToEvent(Map<String, String> em) {
		
		Event e= EventGenerator.getNext();
		
		try {
		Schema s = e.getSchema();
		List<Schema.Field> fields = s.getFields();
		for (Schema.Field field : fields) {
			if (field == null) continue;
			System.out.print("\r\nmapToEvent : Field name = " + field.name() + ". value = " + em.get(field.name()));
			Object v = e.get(field.name());
			
			Object obv = getValue(v,em.get(field.name()));
			if(obv != null)
				e.put(field.name(), obv);
		} }catch (Exception ex) {
			ex.printStackTrace();
		}
		e = Event.newBuilder(e).build();
		return e;
	}
	
	public static Object getValue(Object v, String vstr) {
		if (vstr == null) return null;
		Object rtnObject = null;
		if (v instanceof CharSequence)
			rtnObject = vstr;
		else if (v instanceof Integer)
			rtnObject = Integer.valueOf(vstr);
		else if (v instanceof Long)
			rtnObject = Long.valueOf(vstr);
		if (rtnObject == null)
			rtnObject = v;
		return rtnObject;
	}
	
    public static String convertToStr(Event e) {
    	StringBuffer log = new StringBuffer("");

		log.append("Debug Event Data: " + "\r\n");
		log.append("transactionId : " + e.getTransactionId() + "\r\n");
		log.append("type : " + e.getFilePath() + "\r\n");
		//log.append("tradeId : " + e.getID() + "\r\n");
		log.append("blockId : " + e.getBlockExternalReferenceId() + "\r\n");
		log.append("firmCode : " + e.getFirmCode() + "\r\n");
		log.append("assetClass : " + e.getAssetClass()+ "\r\n");
		log.append("custodian Account : " + e.getCustodianAccount() + "\r\n");
		log.append("source : " + e.getSource() + "\r\n");
		//log.append("stage : " + e.getStatus() + "\r\n");
		log.append("category : " + e.getExceptionCategory() + "\r\n");
		log.append("description : " + e.getErrorDescription() + "\r\n");
    	
    	return log.toString();
    }
}
