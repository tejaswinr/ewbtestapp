package com.citigroup.ewb.common.util;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.DoubleDeserializer;
import org.apache.kafka.common.serialization.DoubleSerializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

public class DoubleSerde  implements Serde<Double>  {
    private DoubleSerializer serializer = new DoubleSerializer();
    private DoubleDeserializer deserializer = new DoubleDeserializer();
	@Override
	public void close() {
		// TODO Auto-generated method stub
		serializer.close();
		deserializer.close();
	}

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		// TODO Auto-generated method stub
        serializer.configure(configs, isKey);
        deserializer.configure(configs, isKey);
	}

	@Override
	public Deserializer<Double> deserializer() {
		// TODO Auto-generated method stub
		return deserializer;
	}

	@Override
	public Serializer<Double> serializer() {
		// TODO Auto-generated method stub
		return serializer;
	}

}
