package com.citigroup.ewb.domain;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * 
 * @startuml
 * 
 * TaskExecutor -> EventRouter : routing
 * EventRouter ->EventKafkaStream : buildEventStreams
 * EventKafkaStream ->EventKafkaStream : KafkaStream buildEventStreams()
 * EventKafkaStream -> KafkaStream : start
 * @enduml
*/
@Service
public class EventRouter implements ProcessService {

	private static final Logger logger = LogManager.getLogger(EventRouter.class);
	
    @Autowired
    EventKafkaStream kafkaStream;
    
    @Async("processExecutor") 
    @Override 
    public CompletableFuture<AtomicLong> process() {
    	System.out.print("Start routing streaming.\r\n");
    	
    	long starttimestamp = System.currentTimeMillis();
    	
    	try {
			kafkaStream.startStreaming();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	logger.info("routing streaming is stopping");
    	long endtimestamp =	 System.currentTimeMillis();
    	try {
			Thread.sleep(1000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	logger.info("Streaming time is " + (endtimestamp - starttimestamp)/1000 + " seconds. ");
    	logger.info("routing streaming stops.");
    	
		return CompletableFuture.completedFuture(EventKafkaStream.getTotalProcessedEvents());
    }
    
    public void stop() {
    	try {
			this.kafkaStream.stopStreaming();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
