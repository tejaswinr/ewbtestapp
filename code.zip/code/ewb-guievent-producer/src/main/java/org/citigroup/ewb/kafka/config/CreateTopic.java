package org.citigroup.ewb.kafka.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CreateTopic {
//	@Bean
//	public NewTopic testEwbTp() {
//		return new NewTopic("testEwbTp", 3, (short) 1);
//	}
}
