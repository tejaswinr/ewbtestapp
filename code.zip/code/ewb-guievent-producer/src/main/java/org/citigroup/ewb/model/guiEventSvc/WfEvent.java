package org.citigroup.ewb.model.guiEventSvc;

public class WfEvent {
	private String type;
	private String coreSystem;
	private TradeProcessingException tpExceptionObject;
	private TradeProcessingRemediation tpRemediationObject;
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCoreSystem() {
		return coreSystem;
	}

	public void setCoreSystem(String coreSystem) {
		this.coreSystem = coreSystem;
	}

	public TradeProcessingException getExceptionObj() {
		return tpExceptionObject;
	}

	public void setExceptionObj(TradeProcessingException tpExceptionObject) {
		this.tpExceptionObject = tpExceptionObject;
	}
	public TradeProcessingRemediation getRemediationObj() {
		return tpRemediationObject;
	}

	public void setRemediationObj(TradeProcessingRemediation tpRemediationObject) {
		this.tpRemediationObject = tpRemediationObject;
	}
}
