package org.citigroup.ewb.model.guiEventSvc;

public class TradeProcessingRemediation {

	private String transactionId;
	private String custodianAccount;

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getCustodianAccount() {
		return custodianAccount;
	}

	public void setCustodianAccount(String custodianAccount) {
		this.custodianAccount = custodianAccount;
	}
}
