package org.citigroup.ewb.model.guiEventSvc;

/**
 * Created by Sunil Yadav on 12/18/2017.
 */


public class Event {

    private String type;
    private String coreSystem;
    private String id;
    private String assignee;
    private String transactionId;
    private String custodianAccount;
    private String status;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCoreSystem() {
        return coreSystem;
    }

    public void setCoreSystem(String coreSystem) {
        this.coreSystem = coreSystem;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCustodianAccount() {
        return custodianAccount;
    }

    public void setCustodianAccount(String custodianAccount) {
        this.custodianAccount = custodianAccount;
    }

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
}