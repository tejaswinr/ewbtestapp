//package org.citigroup.ewb.kafka.interaction;
//
//import java.util.concurrent.CountDownLatch;
//
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.citigroup.ewb.model.guiEventSvc.WfEvent;
//import org.citigroup.ewb.model.queryAPiSvc.QueryGqlResponse;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.kafka.support.Acknowledgment;
//import org.springframework.web.client.RestTemplate;
//
//public class Receiver {
//
//	private static final Logger LOGGER = LoggerFactory
//			.getLogger(Receiver.class);
//
//	private CountDownLatch latch = new CountDownLatch(1);
//
//	public CountDownLatch getLatch() {
//		return latch;
//	}
//
//	@KafkaListener(topics = "${kafka.topic.ewb}", groupId = "${kafka.topic.ewb.groupId}")
//	public void receive(ConsumerRecord<Integer, WfEvent> cr, Acknowledgment ack) {
//		LOGGER.info("START");
//		LOGGER.info("received offset='{}'", cr.offset());
//		LOGGER.info("received partition='{}'", cr.partition());
//		LOGGER.info("received topic='{}'", cr.topic());
//		LOGGER.info("received assignee='{}'", cr.value().getExceptionObj()
//				.getAssignee());
//		String gqlApi = "http://gcotdvmmw795456:4000/graphqlTP";
//
//		HttpHeaders httpHeaders = new HttpHeaders();
//		httpHeaders.set("Content-Type", "application/json");
//
//		String gqlQuery = "{\"query\":\"mutation { updateAssignee(_id:\\\""
//				+ cr.value().getExceptionObj().getId() + "\\\", value:\\\""
//				+ cr.value().getExceptionObj().getAssignee()
//				+ "\\\") {assignee}}\"}";
//		HttpEntity<String> httpEntity = new HttpEntity<String>(gqlQuery,
//				httpHeaders);
//		LOGGER.info(gqlQuery);
//
//		RestTemplate restTemplate = new RestTemplate();
//		QueryGqlResponse response = restTemplate.postForObject(gqlApi, httpEntity,
//				QueryGqlResponse.class);
//		LOGGER.info(response.getData().getUpdateAssignee().getAssignee());
//		ack.acknowledge();
//		LOGGER.info("END");
//	}
//}
