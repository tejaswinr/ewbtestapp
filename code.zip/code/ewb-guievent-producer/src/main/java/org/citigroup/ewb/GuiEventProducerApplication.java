package org.citigroup.ewb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuiEventProducerApplication {

  public static void main(String[] args) {
    SpringApplication.run(GuiEventProducerApplication.class, args);
  }
}